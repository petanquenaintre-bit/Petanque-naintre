import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  User,
  Mail,
  Calendar,
  Shield,
  Award,
  MessageSquare,
  Trophy,
  Lock,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle,
} from 'lucide-react';

export default function Profil() {
  const { user, changePassword } = useAuth();

  const [currentPwd, setCurrentPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [showCurrentPwd, setShowCurrentPwd] = useState(false);
  const [showNewPwd, setShowNewPwd] = useState(false);
  const [pwdError, setPwdError] = useState('');
  const [pwdSuccess, setPwdSuccess] = useState('');

  if (!user) return null;

  function handleChangePassword(e: React.FormEvent) {
    e.preventDefault();
    setPwdError('');
    setPwdSuccess('');

    if (!currentPwd || !newPwd || !confirmPwd) {
      setPwdError('Veuillez remplir tous les champs.');
      return;
    }

    if (newPwd !== confirmPwd) {
      setPwdError('Les nouveaux mots de passe ne correspondent pas.');
      return;
    }

    const result = changePassword(currentPwd, newPwd);

    if (result.success) {
      setPwdSuccess('✅ Mot de passe modifié avec succès !');
      setCurrentPwd('');
      setNewPwd('');
      setConfirmPwd('');
    } else {
      setPwdError(result.error || 'Erreur lors du changement.');
    }
  }

  return (
    <section id="profil" className="py-16 px-4 sm:px-6 bg-white">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-extrabold text-[#2c3e50] mb-2 flex items-center gap-3">
          <span className="w-1.5 h-8 bg-[#1abc9c] rounded-full inline-block" />
          Mon Profil
        </h2>
        <p className="text-gray-500 mb-10">Votre espace personnel</p>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Carte profil */}
          <div className="md:col-span-1">
            <div className="bg-gradient-to-br from-[#2c3e50] to-[#34495e] rounded-2xl p-6 text-center text-white">
              <div className="w-20 h-20 bg-[#1abc9c]/20 rounded-full flex items-center justify-center text-4xl mx-auto mb-4 border-3 border-[#1abc9c]">
                {user.avatar}
              </div>
              <h3 className="font-bold text-lg">
                {user.prenom} {user.nom}
              </h3>
              <p className="text-[#1abc9c] text-sm font-semibold">@{user.pseudo}</p>
              <div className="mt-3">
                <span className="bg-[#1abc9c] text-white text-xs font-bold px-3 py-1 rounded-full uppercase">
                  {user.role}
                </span>
              </div>
              <div className="mt-4 pt-4 border-t border-white/10 text-xs text-gray-400">
                Membre depuis le {user.dateInscription}
              </div>
            </div>
          </div>

          {/* Infos détaillées */}
          <div className="md:col-span-2 space-y-5">
            {/* Informations personnelles */}
            <div className="bg-gray-50 rounded-xl p-6 border border-gray-100">
              <h4 className="font-bold text-[#2c3e50] mb-4 flex items-center gap-2">
                <User size={18} className="text-[#1abc9c]" />
                Informations personnelles
              </h4>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-400 font-semibold uppercase">Prénom</label>
                  <p className="text-[#2c3e50] font-medium">{user.prenom}</p>
                </div>
                <div>
                  <label className="text-xs text-gray-400 font-semibold uppercase">Nom</label>
                  <p className="text-[#2c3e50] font-medium">{user.nom}</p>
                </div>
                <div>
                  <label className="text-xs text-gray-400 font-semibold uppercase flex items-center gap-1">
                    <Mail size={12} /> Email
                  </label>
                  <p className="text-[#2c3e50] font-medium">{user.email}</p>
                </div>
                <div>
                  <label className="text-xs text-gray-400 font-semibold uppercase flex items-center gap-1">
                    <Calendar size={12} /> Inscrit le
                  </label>
                  <p className="text-[#2c3e50] font-medium">{user.dateInscription}</p>
                </div>
                <div>
                  <label className="text-xs text-gray-400 font-semibold uppercase flex items-center gap-1">
                    <Shield size={12} /> Rôle
                  </label>
                  <p className="text-[#1abc9c] font-semibold capitalize">{user.role}</p>
                </div>
              </div>
            </div>

            {/* Stats rapides */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-gray-50 rounded-xl p-4 text-center border border-gray-100">
                <Trophy size={24} className="text-[#f39c12] mx-auto mb-2" />
                <div className="text-xl font-extrabold text-[#2c3e50]">0</div>
                <div className="text-xs text-gray-500">Victoires</div>
              </div>
              <div className="bg-gray-50 rounded-xl p-4 text-center border border-gray-100">
                <Award size={24} className="text-[#1abc9c] mx-auto mb-2" />
                <div className="text-xl font-extrabold text-[#2c3e50]">0</div>
                <div className="text-xs text-gray-500">Concours</div>
              </div>
              <div className="bg-gray-50 rounded-xl p-4 text-center border border-gray-100">
                <MessageSquare size={24} className="text-[#3498db] mx-auto mb-2" />
                <div className="text-xl font-extrabold text-[#2c3e50]">0</div>
                <div className="text-xs text-gray-500">Messages</div>
              </div>
            </div>

            {/* ======= CHANGER MOT DE PASSE ======= */}
            <div className="bg-gray-50 rounded-xl p-6 border border-gray-100">
              <h4 className="font-bold text-[#2c3e50] mb-4 flex items-center gap-2">
                <Lock size={18} className="text-[#e74c3c]" />
                Changer mon mot de passe
              </h4>

              {pwdSuccess && (
                <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm flex items-center gap-2 mb-4">
                  <CheckCircle size={16} className="shrink-0" />
                  {pwdSuccess}
                </div>
              )}

              {pwdError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm flex items-center gap-2 mb-4">
                  <AlertCircle size={16} className="shrink-0" />
                  {pwdError}
                </div>
              )}

              <form onSubmit={handleChangePassword} className="space-y-4">
                {/* Mot de passe actuel */}
                <div>
                  <label className="block text-sm font-semibold text-[#2c3e50] mb-1.5">
                    Mot de passe actuel
                  </label>
                  <div className="relative">
                    <input
                      type={showCurrentPwd ? 'text' : 'password'}
                      value={currentPwd}
                      onChange={(e) => { setCurrentPwd(e.target.value); setPwdError(''); setPwdSuccess(''); }}
                      placeholder="Entrez votre mot de passe actuel"
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent pr-10 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowCurrentPwd(!showCurrentPwd)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showCurrentPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                {/* Nouveau mot de passe */}
                <div>
                  <label className="block text-sm font-semibold text-[#2c3e50] mb-1.5">
                    Nouveau mot de passe <span className="text-gray-400 font-normal">(min. 4 caractères)</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPwd ? 'text' : 'password'}
                      value={newPwd}
                      onChange={(e) => { setNewPwd(e.target.value); setPwdError(''); setPwdSuccess(''); }}
                      placeholder="Entrez votre nouveau mot de passe"
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent pr-10 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPwd(!showNewPwd)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showNewPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                {/* Confirmer nouveau mot de passe */}
                <div>
                  <label className="block text-sm font-semibold text-[#2c3e50] mb-1.5">
                    Confirmer le nouveau mot de passe
                  </label>
                  <input
                    type={showNewPwd ? 'text' : 'password'}
                    value={confirmPwd}
                    onChange={(e) => { setConfirmPwd(e.target.value); setPwdError(''); setPwdSuccess(''); }}
                    placeholder="Confirmez votre nouveau mot de passe"
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent transition-all"
                  />
                  {confirmPwd && newPwd !== confirmPwd && (
                    <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                      <AlertCircle size={12} /> Les mots de passe ne correspondent pas
                    </p>
                  )}
                  {confirmPwd && newPwd === confirmPwd && newPwd.length >= 4 && (
                    <p className="text-green-500 text-xs mt-1 flex items-center gap-1">
                      <CheckCircle size={12} /> Les mots de passe correspondent
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  className="bg-[#e74c3c] hover:bg-[#c0392b] text-white px-6 py-2.5 rounded-lg font-bold text-sm transition-colors flex items-center gap-2"
                >
                  <Lock size={16} />
                  Changer le mot de passe
                </button>
              </form>
            </div>

            {/* Message de bienvenue */}
            <div className="bg-[#1abc9c]/10 border border-[#1abc9c]/20 rounded-xl p-5">
              <h4 className="font-bold text-[#2c3e50] mb-2">🎉 Bienvenue {user.prenom} !</h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                Votre compte est actif. Vous pouvez désormais participer au forum, consulter les
                scores et classements, et accéder à toutes les fonctionnalités réservées aux membres
                du club Pétanque Naintréenne.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
