import { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { FAQItem } from '../context/DataContext';
import { AddButton, EditButton, DeleteButton, EditModal, Field, SaveButton, ConfirmDelete } from './AdminActions';

const uid = () => Date.now().toString() + Math.random().toString(36).slice(2, 6);

export default function FAQ() {
  const { faq, setFAQ } = useData();
  const [open, setOpen] = useState<number | null>(null);
  const [editF, setEditF] = useState<FAQItem | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [delId, setDelId] = useState<string | null>(null);

  const [fQ, setFQ] = useState(''); const [fA, setFA] = useState('');

  function openAdd() { setFQ(''); setFA(''); setShowAdd(true); }
  function openEdit(f: FAQItem) { setFQ(f.q); setFA(f.a); setEditF(f); }
  function saveFaq(e: React.FormEvent) { e.preventDefault();
    if (editF) { setFAQ(faq.map(f => f.id === editF.id ? { ...f, q: fQ, a: fA } : f)); setEditF(null); }
    else { setFAQ([...faq, { id: uid(), q: fQ, a: fA }]); setShowAdd(false); }
  }

  return (
    <section id="faq" className="py-16 px-4 sm:px-6 bg-white">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-3xl font-extrabold text-[#2c3e50] flex items-center gap-3">
            <span className="w-1.5 h-8 bg-[#1abc9c] rounded-full inline-block" /> FAQ
          </h2>
          <AddButton onClick={openAdd} label="Ajouter une question" />
        </div>
        <p className="text-gray-500 mb-10">Questions fréquemment posées</p>

        <div className="space-y-3">
          {faq.map((item, i) => (
            <div key={item.id} className="bg-gray-50 rounded-xl border border-gray-100 overflow-hidden relative group">
              <div className="absolute top-3 right-10 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <EditButton onClick={() => openEdit(item)} />
                <DeleteButton onClick={() => setDelId(item.id)} />
              </div>
              <button onClick={() => setOpen(open === i ? null : i)} className="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-gray-100 transition-colors">
                <span className="flex items-center gap-3 font-semibold text-[#2c3e50] text-sm pr-16"><HelpCircle size={18} className="text-[#1abc9c] shrink-0" />{item.q}</span>
                <ChevronDown size={18} className={`text-gray-400 shrink-0 transition-transform ${open === i ? 'rotate-180' : ''}`} />
              </button>
              {open === i && <div className="px-5 pb-4 pl-12"><p className="text-gray-600 text-sm leading-relaxed">{item.a}</p></div>}
            </div>
          ))}
        </div>
        {faq.length === 0 && <p className="text-gray-400 text-center py-12">Aucune question</p>}
      </div>

      <EditModal open={showAdd || !!editF} onClose={() => { setShowAdd(false); setEditF(null); }} title={editF ? 'Modifier la question' : 'Nouvelle question'}>
        <form onSubmit={saveFaq} className="space-y-3">
          <Field label="Question" value={fQ} onChange={setFQ} placeholder="Comment s'inscrire ?" required />
          <Field label="Réponse" value={fA} onChange={setFA} type="textarea" placeholder="La réponse..." required />
          <SaveButton />
        </form>
      </EditModal>

      {delId && <ConfirmDelete message="Supprimer cette question ?" onConfirm={() => { setFAQ(faq.filter(f => f.id !== delId)); setDelId(null); }} onCancel={() => setDelId(null)} />}
    </section>
  );
}
