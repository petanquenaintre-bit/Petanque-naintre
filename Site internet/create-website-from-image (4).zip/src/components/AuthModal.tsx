import { useState } from 'react';
import { X, LogIn, UserPlus, Eye, EyeOff, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function AuthModal() {
  const { showAuthModal, setShowAuthModal, authTab, setAuthTab, login, register } = useAuth();

  const [loginPseudo, setLoginPseudo] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [showLoginPwd, setShowLoginPwd] = useState(false);

  const [regPseudo, setRegPseudo] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regNom, setRegNom] = useState('');
  const [regPrenom, setRegPrenom] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regPassword2, setRegPassword2] = useState('');
  const [regError, setRegError] = useState('');
  const [regSuccess, setRegSuccess] = useState(false);
  const [showRegPwd, setShowRegPwd] = useState(false);

  if (!showAuthModal) return null;

  function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoginError('');

    if (!loginPseudo.trim() || !loginPassword.trim()) {
      setLoginError('Veuillez remplir tous les champs.');
      return;
    }

    const result = login(loginPseudo.trim(), loginPassword);
    if (!result.success) {
      setLoginError(result.error || 'Erreur de connexion.');
    }
  }

  function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setRegError('');
    setRegSuccess(false);

    if (!regPseudo.trim() || !regEmail.trim() || !regPassword.trim() || !regNom.trim() || !regPrenom.trim()) {
      setRegError('Veuillez remplir tous les champs.');
      return;
    }

    if (regPassword !== regPassword2) {
      setRegError('Les mots de passe ne correspondent pas.');
      return;
    }

    const result = register({
      pseudo: regPseudo.trim(),
      email: regEmail.trim(),
      nom: regNom.trim(),
      prenom: regPrenom.trim(),
      password: regPassword,
    });

    if (!result.success) {
      setRegError(result.error || "Erreur lors de l'inscription.");
    } else {
      setRegSuccess(true);
    }
  }

  function handleClose() {
    setShowAuthModal(false);
    setLoginError('');
    setRegError('');
    setRegSuccess(false);
    setLoginPseudo('');
    setLoginPassword('');
    setRegPseudo('');
    setRegEmail('');
    setRegNom('');
    setRegPrenom('');
    setRegPassword('');
    setRegPassword2('');
  }

  function switchToRegister() {
    setAuthTab('register');
    setLoginError('');
    setRegSuccess(false);
  }

  function switchToLogin() {
    setAuthTab('login');
    setRegError('');
    setRegSuccess(false);
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={handleClose} />

      {/* Modal */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-[fadeIn_0.2s_ease-out]">
        {/* Header */}
        <div className="bg-[#2c3e50] px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="/images/logo.png"
              alt="Logo"
              className="w-10 h-10 rounded-full border-2 border-[#1abc9c] object-cover"
            />
            <div>
              <h2 className="text-white font-bold text-lg">
                {authTab === 'login' ? 'Connexion' : 'Inscription'}
              </h2>
              <p className="text-gray-400 text-xs">Pétanque Naintréenne</p>
            </div>
          </div>
          <button onClick={handleClose} className="text-gray-400 hover:text-white transition-colors p-1">
            <X size={20} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200">
          <button
            onClick={switchToLogin}
            className={`flex-1 py-3 text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${
              authTab === 'login'
                ? 'text-[#1abc9c] border-b-2 border-[#1abc9c] bg-[#1abc9c]/5'
                : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <LogIn size={16} />
            Se connecter
          </button>
          <button
            onClick={switchToRegister}
            className={`flex-1 py-3 text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${
              authTab === 'register'
                ? 'text-[#1abc9c] border-b-2 border-[#1abc9c] bg-[#1abc9c]/5'
                : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <UserPlus size={16} />
            Demander un compte
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {authTab === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              {loginError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm flex items-start gap-2">
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                  <span>{loginError}</span>
                </div>
              )}

              <div>
                <label className="block text-sm font-semibold text-[#2c3e50] mb-1.5">
                  Pseudo ou Email
                </label>
                <input
                  type="text"
                  value={loginPseudo}
                  onChange={(e) => setLoginPseudo(e.target.value)}
                  placeholder="Votre pseudo ou email"
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent transition-all"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#2c3e50] mb-1.5">
                  Mot de passe
                </label>
                <div className="relative">
                  <input
                    type={showLoginPwd ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Votre mot de passe"
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent pr-10 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPwd(!showLoginPwd)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showLoginPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#1abc9c] hover:bg-[#16a085] text-white py-3 rounded-lg font-bold text-sm transition-colors flex items-center justify-center gap-2"
              >
                <LogIn size={18} />
                Se connecter
              </button>

              <p className="text-center text-sm text-gray-500">
                Pas encore de compte ?{' '}
                <button type="button" onClick={switchToRegister} className="text-[#1abc9c] font-semibold hover:underline">
                  Demandez l'accès
                </button>
              </p>
            </form>
          ) : (
            <>
              {regSuccess ? (
                /* Message de succès après inscription */
                <div className="text-center py-6">
                  <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Clock size={32} className="text-amber-600" />
                  </div>
                  <h3 className="text-xl font-bold text-[#2c3e50] mb-2">Demande envoyée !</h3>
                  <p className="text-gray-600 text-sm leading-relaxed mb-4">
                    Votre demande d'inscription a bien été enregistrée.<br />
                    <strong className="text-amber-600">L'administrateur doit approuver votre compte</strong> avant que vous puissiez vous connecter.
                  </p>
                  <p className="text-gray-400 text-xs mb-6">
                    Vous recevrez l'accès une fois votre demande validée. Revenez plus tard pour essayer de vous connecter.
                  </p>
                  <button
                    onClick={switchToLogin}
                    className="bg-[#2c3e50] hover:bg-[#34495e] text-white px-6 py-2.5 rounded-lg font-semibold text-sm transition-colors"
                  >
                    Retour à la connexion
                  </button>
                </div>
              ) : (
                <form onSubmit={handleRegister} className="space-y-3">
                  {/* Info banner */}
                  <div className="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-3 rounded-lg text-xs flex items-start gap-2">
                    <Clock size={14} className="shrink-0 mt-0.5" />
                    <span>
                      <strong>Inscription soumise à validation.</strong> Votre compte devra être approuvé par l'administrateur avant de pouvoir vous connecter.
                    </span>
                  </div>

                  {regError && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm flex items-center gap-2">
                      <AlertCircle size={16} className="shrink-0" />
                      {regError}
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-semibold text-[#2c3e50] mb-1">Prénom</label>
                      <input
                        type="text"
                        value={regPrenom}
                        onChange={(e) => setRegPrenom(e.target.value)}
                        placeholder="Jean"
                        className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#2c3e50] mb-1">Nom</label>
                      <input
                        type="text"
                        value={regNom}
                        onChange={(e) => setRegNom(e.target.value)}
                        placeholder="Dupont"
                        className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#2c3e50] mb-1">
                      Pseudo <span className="text-gray-400 font-normal">(min. 3 caractères)</span>
                    </label>
                    <input
                      type="text"
                      value={regPseudo}
                      onChange={(e) => setRegPseudo(e.target.value)}
                      placeholder="MonPseudo86"
                      className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#2c3e50] mb-1">Email</label>
                    <input
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="jean.dupont@email.fr"
                      className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#2c3e50] mb-1">
                      Mot de passe <span className="text-gray-400 font-normal">(min. 4 caractères)</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showRegPwd ? 'text' : 'password'}
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent pr-10 transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowRegPwd(!showRegPwd)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {showRegPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#2c3e50] mb-1">Confirmer le mot de passe</label>
                    <input
                      type={showRegPwd ? 'text' : 'password'}
                      value={regPassword2}
                      onChange={(e) => setRegPassword2(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent transition-all"
                    />
                    {regPassword2 && regPassword !== regPassword2 && (
                      <p className="text-red-500 text-xs mt-1">Les mots de passe ne correspondent pas</p>
                    )}
                    {regPassword2 && regPassword === regPassword2 && regPassword.length >= 4 && (
                      <p className="text-green-500 text-xs mt-1 flex items-center gap-1">
                        <CheckCircle size={12} /> Les mots de passe correspondent
                      </p>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#1abc9c] hover:bg-[#16a085] text-white py-3 rounded-lg font-bold text-sm transition-colors flex items-center justify-center gap-2 mt-2"
                  >
                    <UserPlus size={18} />
                    Envoyer ma demande
                  </button>

                  <p className="text-center text-sm text-gray-500">
                    Déjà un compte approuvé ?{' '}
                    <button type="button" onClick={switchToLogin} className="text-[#1abc9c] font-semibold hover:underline">
                      Connectez-vous
                    </button>
                  </p>
                </form>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
