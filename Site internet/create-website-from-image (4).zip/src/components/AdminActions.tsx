import { Plus, Pencil, Trash2, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import type { ReactNode } from 'react';

// Boutons admin visibles uniquement pour l'admin
export function AddButton({ onClick, label }: { onClick: () => void; label?: string }) {
  const { user } = useAuth();
  if (!user || user.role !== 'admin') return null;
  return (
    <button onClick={onClick} className="flex items-center gap-1.5 bg-[#1abc9c] hover:bg-[#16a085] text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-colors">
      <Plus size={14} /> {label || 'Ajouter'}
    </button>
  );
}

export function EditButton({ onClick }: { onClick: () => void }) {
  const { user } = useAuth();
  if (!user || user.role !== 'admin') return null;
  return (
    <button onClick={onClick} className="text-gray-400 hover:text-[#3498db] p-1 rounded transition-colors" title="Modifier">
      <Pencil size={14} />
    </button>
  );
}

export function DeleteButton({ onClick }: { onClick: () => void }) {
  const { user } = useAuth();
  if (!user || user.role !== 'admin') return null;
  return (
    <button onClick={onClick} className="text-gray-400 hover:text-[#e74c3c] p-1 rounded transition-colors" title="Supprimer">
      <Trash2 size={14} />
    </button>
  );
}

// Modal générique
export function EditModal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-[fadeIn_0.2s_ease-out]">
        <div className="bg-[#2c3e50] px-5 py-4 flex items-center justify-between rounded-t-2xl sticky top-0 z-10">
          <h3 className="text-white font-bold text-base">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors"><X size={18} /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

// Champ de formulaire
export function Field({ label, value, onChange, type = 'text', placeholder = '', required = false }: {
  label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string; required?: boolean;
}) {
  return (
    <div>
      <label className="block text-sm font-semibold text-[#2c3e50] mb-1">{label}</label>
      {type === 'textarea' ? (
        <textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} required={required}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent resize-y min-h-[80px]" />
      ) : (
        <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} required={required}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c] focus:border-transparent" />
      )}
    </div>
  );
}

export function SaveButton({ label }: { label?: string }) {
  return (
    <button type="submit" className="w-full bg-[#1abc9c] hover:bg-[#16a085] text-white py-2.5 rounded-lg font-bold text-sm transition-colors mt-3">
      {label || 'Enregistrer'}
    </button>
  );
}

export function ConfirmDelete({ message, onConfirm, onCancel }: { message: string; onConfirm: () => void; onCancel: () => void }) {
  return (
    <div className="fixed inset-0 z-[95] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onCancel} />
      <div className="relative bg-white rounded-xl p-6 shadow-2xl max-w-sm w-full text-center">
        <Trash2 size={32} className="text-[#e74c3c] mx-auto mb-3" />
        <p className="text-[#2c3e50] font-semibold mb-1">Confirmer la suppression</p>
        <p className="text-gray-500 text-sm mb-5">{message}</p>
        <div className="flex gap-3">
          <button onClick={onCancel} className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 py-2 rounded-lg font-semibold text-sm transition-colors">Annuler</button>
          <button onClick={onConfirm} className="flex-1 bg-[#e74c3c] hover:bg-[#c0392b] text-white py-2 rounded-lg font-semibold text-sm transition-colors">Supprimer</button>
        </div>
      </div>
    </div>
  );
}
