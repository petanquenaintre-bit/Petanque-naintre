import { MapPin, Mail, Phone } from 'lucide-react';
import { FooterCounter } from './VisitorCounter';

export default function Footer() {
  return (
    <footer className="bg-[#2c3e50] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <img
                src="/images/logo.png"
                alt="Logo"
                className="w-10 h-10 rounded-full object-cover border-2 border-[#1abc9c]"
              />
              <div>
                <div className="font-bold text-sm">PÉTANQUE</div>
                <div className="text-[#1abc9c] text-xs font-semibold">NAINTRÉENNE</div>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Club de pétanque affilié à la FFPJP, basé à Naintré dans la Vienne (86).
            </p>
          </div>

          {/* Liens rapides */}
          <div>
            <h4 className="font-bold text-sm mb-4 text-[#1abc9c]">LIENS RAPIDES</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#accueil" className="hover:text-[#1abc9c] transition-colors">Accueil</a></li>
              <li><a href="#actualites" className="hover:text-[#1abc9c] transition-colors">Actualités</a></li>
              <li><a href="#club" className="hover:text-[#1abc9c] transition-colors">Notre Club</a></li>
              <li><a href="#saison" className="hover:text-[#1abc9c] transition-colors">Saison</a></li>
              <li><a href="#scores" className="hover:text-[#1abc9c] transition-colors">Scores</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-sm mb-4 text-[#1abc9c]">CONTACT</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li className="flex items-start gap-2">
                <MapPin size={14} className="shrink-0 mt-0.5 text-[#1abc9c]" />
                Boulodrome Municipal, 86530 Naintré
              </li>
              <li className="flex items-center gap-2">
                <Phone size={14} className="text-[#1abc9c]" />
                05 49 XX XX XX
              </li>
              <li className="flex items-center gap-2">
                <Mail size={14} className="text-[#1abc9c]" />
                petanque.naintreenne@email.fr
              </li>
            </ul>
          </div>

          {/* Compteur de visites */}
          <div>
            <FooterCounter />
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-gray-500">
          <p>© 2025 Pétanque Naintréenne. Tous droits réservés.</p>
          <p>Club affilié FFPJP · Vienne (86)</p>
        </div>
      </div>
    </footer>
  );
}
