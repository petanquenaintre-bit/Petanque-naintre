import {
  Newspaper,
  Trophy,
  Calendar,
  Award,
  Camera,
  Handshake,
  CreditCard,
  MessageSquare,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface CardData {
  icon: LucideIcon;
  title: string;
  description: string;
  href: string;
}

const topCards: CardData[] = [
  {
    icon: Newspaper,
    title: 'Actualités',
    description: 'Concours, résultats, vie du club...',
    href: '#actualites',
  },
  {
    icon: Trophy,
    title: 'Notre Club',
    description: 'Dirigeants, agenda, arbitres...',
    href: '#club',
  },
  {
    icon: Calendar,
    title: 'Saison 2024–2025',
    description: 'Joueurs, calendriers équipes...',
    href: '#saison',
  },
  {
    icon: Award,
    title: 'Scores & Classements',
    description: 'Entrez les scores → classement automatique !',
    href: '#scores',
  },
];

const bottomCards: CardData[] = [
  {
    icon: Camera,
    title: 'Médias',
    description: 'Photos et vidéos du club.',
    href: '#medias',
  },
  {
    icon: Handshake,
    title: 'Partenaires',
    description: 'Nos sponsors et partenaires.',
    href: '#partenaires',
  },
  {
    icon: CreditCard,
    title: 'Licences',
    description: 'Adultes 40€ · Juniors 15€ · Jeunes Gratuit',
    href: '#licences',
  },
  {
    icon: MessageSquare,
    title: 'Forum',
    description: 'Échangez avec les membres.',
    href: '#forum',
  },
];

function CategoryCard({ card }: { card: CardData }) {
  const Icon = card.icon;
  return (
    <a
      href={card.href}
      className="group block bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden border border-gray-100"
    >
      {/* Card Header */}
      <div className="bg-[#1abc9c] px-5 py-3.5 flex items-center gap-3">
        <div className="bg-white/20 p-1.5 rounded">
          <Icon size={20} className="text-white" />
        </div>
        <h3 className="text-white font-bold text-base">{card.title}</h3>
      </div>
      {/* Card Body */}
      <div className="px-5 py-4">
        <p className="text-gray-600 text-sm leading-relaxed">{card.description}</p>
      </div>
    </a>
  );
}

export default function CategoryCards() {
  return (
    <section className="bg-[#ecf0f1] py-10 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Top Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {topCards.map((card) => (
            <CategoryCard key={card.title} card={card} />
          ))}
        </div>
        {/* Bottom Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {bottomCards.map((card) => (
            <CategoryCard key={card.title} card={card} />
          ))}
        </div>
      </div>
    </section>
  );
}
