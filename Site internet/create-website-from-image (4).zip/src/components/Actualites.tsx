import { useState } from 'react';
import { Calendar, MapPin, Users } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { NewsItem, EventItem } from '../context/DataContext';
import { AddButton, EditButton, DeleteButton, EditModal, Field, SaveButton, ConfirmDelete } from './AdminActions';

const uid = () => Date.now().toString() + Math.random().toString(36).slice(2, 6);

export default function Actualites() {
  const { news, setNews, events, setEvents } = useData();
  const [editNews, setEditNews] = useState<NewsItem | null>(null);
  const [editEvent, setEditEvent] = useState<EventItem | null>(null);
  const [delId, setDelId] = useState<{ type: 'news' | 'event'; id: string } | null>(null);
  const [showAddNews, setShowAddNews] = useState(false);
  const [showAddEvent, setShowAddEvent] = useState(false);

  // News form
  const [nDate, setNDate] = useState(''); const [nTitle, setNTitle] = useState(''); const [nDesc, setNDesc] = useState(''); const [nTag, setNTag] = useState('');
  // Event form
  const [eDate, setEDate] = useState(''); const [eTitle, setETitle] = useState(''); const [eLoc, setELoc] = useState(''); const [ePart, setEPart] = useState('');

  function openAddNews() { setNDate(''); setNTitle(''); setNDesc(''); setNTag('Résultats'); setShowAddNews(true); }
  function openEditNews(n: NewsItem) { setNDate(n.date); setNTitle(n.title); setNDesc(n.description); setNTag(n.tag); setEditNews(n); }
  function saveNews(e: React.FormEvent) { e.preventDefault();
    if (editNews) { setNews(news.map(n => n.id === editNews.id ? { ...n, date: nDate, title: nTitle, description: nDesc, tag: nTag } : n)); setEditNews(null); }
    else { setNews([{ id: uid(), date: nDate, title: nTitle, description: nDesc, tag: nTag }, ...news]); setShowAddNews(false); }
  }

  function openAddEvent() { setEDate(''); setETitle(''); setELoc(''); setEPart(''); setShowAddEvent(true); }
  function openEditEvent(ev: EventItem) { setEDate(ev.date); setETitle(ev.title); setELoc(ev.location); setEPart(ev.participants); setEditEvent(ev); }
  function saveEvent(e: React.FormEvent) { e.preventDefault();
    if (editEvent) { setEvents(events.map(ev => ev.id === editEvent.id ? { ...ev, date: eDate, title: eTitle, location: eLoc, participants: ePart } : ev)); setEditEvent(null); }
    else { setEvents([...events, { id: uid(), date: eDate, title: eTitle, location: eLoc, participants: ePart }]); setShowAddEvent(false); }
  }

  function handleDelete() {
    if (!delId) return;
    if (delId.type === 'news') setNews(news.filter(n => n.id !== delId.id));
    else setEvents(events.filter(e => e.id !== delId.id));
    setDelId(null);
  }

  return (
    <section id="actualites" className="py-16 px-4 sm:px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-3xl font-extrabold text-[#2c3e50] flex items-center gap-3">
            <span className="w-1.5 h-8 bg-[#1abc9c] rounded-full inline-block" /> Actualités
          </h2>
          <AddButton onClick={openAddNews} label="Ajouter une actu" />
        </div>
        <p className="text-gray-500 mb-10">Les dernières nouvelles du club</p>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-5">
            {news.map((item) => (
              <article key={item.id} className="bg-gray-50 rounded-xl p-5 hover:shadow-md transition-shadow border border-gray-100 relative group">
                <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <EditButton onClick={() => openEditNews(item)} />
                  <DeleteButton onClick={() => setDelId({ type: 'news', id: item.id })} />
                </div>
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-xs font-bold text-white bg-[#1abc9c] px-2.5 py-1 rounded-full">{item.tag}</span>
                  <span className="text-xs text-gray-400 flex items-center gap-1"><Calendar size={12} />{item.date}</span>
                </div>
                <h3 className="text-lg font-bold text-[#2c3e50] mb-1">{item.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{item.description}</p>
              </article>
            ))}
            {news.length === 0 && <p className="text-gray-400 text-center py-8">Aucune actualité</p>}
          </div>

          <aside>
            <div className="bg-[#2c3e50] rounded-xl p-6 text-white">
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-bold text-lg flex items-center gap-2"><Calendar size={20} className="text-[#1abc9c]" /> Événements</h3>
                <AddButton onClick={openAddEvent} label="Ajouter" />
              </div>
              <div className="space-y-4">
                {events.map((event) => (
                  <div key={event.id} className="bg-white/10 rounded-lg p-4 hover:bg-white/15 transition-colors relative group">
                    <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <EditButton onClick={() => openEditEvent(event)} />
                      <DeleteButton onClick={() => setDelId({ type: 'event', id: event.id })} />
                    </div>
                    <div className="text-[#1abc9c] font-bold text-sm mb-1">{event.date}</div>
                    <div className="font-semibold text-sm">{event.title}</div>
                    <div className="text-gray-300 text-xs mt-1.5 flex items-center gap-1"><MapPin size={11} />{event.location}</div>
                    <div className="text-gray-300 text-xs flex items-center gap-1 mt-0.5"><Users size={11} />{event.participants}</div>
                  </div>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </div>

      {/* Modals */}
      <EditModal open={showAddNews || !!editNews} onClose={() => { setShowAddNews(false); setEditNews(null); }} title={editNews ? "Modifier l'actualité" : 'Nouvelle actualité'}>
        <form onSubmit={saveNews} className="space-y-3">
          <Field label="Date" value={nDate} onChange={setNDate} placeholder="15 Janvier 2025" required />
          <Field label="Titre" value={nTitle} onChange={setNTitle} placeholder="Titre de l'actu" required />
          <Field label="Description" value={nDesc} onChange={setNDesc} type="textarea" placeholder="Description..." required />
          <Field label="Tag" value={nTag} onChange={setNTag} placeholder="Résultats, Compétition, Vie du club..." required />
          <SaveButton />
        </form>
      </EditModal>

      <EditModal open={showAddEvent || !!editEvent} onClose={() => { setShowAddEvent(false); setEditEvent(null); }} title={editEvent ? "Modifier l'événement" : 'Nouvel événement'}>
        <form onSubmit={saveEvent} className="space-y-3">
          <Field label="Date" value={eDate} onChange={setEDate} placeholder="25 Jan" required />
          <Field label="Titre" value={eTitle} onChange={setETitle} placeholder="Concours Triplettes" required />
          <Field label="Lieu" value={eLoc} onChange={setELoc} placeholder="Boulodrome de Naintré" required />
          <Field label="Participants" value={ePart} onChange={setEPart} placeholder="48 équipes max" required />
          <SaveButton />
        </form>
      </EditModal>

      {delId && <ConfirmDelete message="Voulez-vous vraiment supprimer cet élément ?" onConfirm={handleDelete} onCancel={() => setDelId(null)} />}
    </section>
  );
}
