import { useState, useRef } from 'react';
import { Users, Calendar, Settings, UserPlus, X, Upload } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { Equipe, MatchItem, JoueurClub } from '../context/DataContext';
import { AddButton, EditButton, DeleteButton, EditModal, Field, SaveButton, ConfirmDelete } from './AdminActions';
import { useAuth } from '../context/AuthContext';

const uid = () => Date.now().toString() + Math.random().toString(36).slice(2, 6);

// ===== Composant Photo Upload =====
function PhotoUpload({ photo, onChange }: { photo: string; onChange: (v: string) => void }) {
  const inputRef = useRef<HTMLInputElement>(null);

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      alert('Fichier trop volumineux (max 2 Mo)');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') onChange(reader.result);
    };
    reader.readAsDataURL(file);
  }

  return (
    <div className="flex flex-col items-center gap-2">
      <div
        className="w-24 h-24 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden cursor-pointer hover:border-[#1abc9c] transition-colors bg-gray-50"
        onClick={() => inputRef.current?.click()}
      >
        {photo ? (
          <img src={photo} alt="Photo" className="w-full h-full object-cover rounded-full" />
        ) : (
          <div className="text-center">
            <Upload size={20} className="text-gray-400 mx-auto" />
            <span className="text-[10px] text-gray-400">Photo</span>
          </div>
        )}
      </div>
      <input ref={inputRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
      {photo && (
        <button type="button" onClick={() => onChange('')} className="text-xs text-red-500 hover:text-red-700 flex items-center gap-1">
          <X size={12} /> Supprimer la photo
        </button>
      )}
    </div>
  );
}

// ===== Badge catégorie =====
function CategorieBadge({ cat }: { cat: string }) {
  const colors: Record<string, string> = {
    'Elite': 'bg-yellow-100 text-yellow-800 border-yellow-300',
    'Honneur': 'bg-blue-100 text-blue-800 border-blue-300',
    'Promotion': 'bg-green-100 text-green-800 border-green-300',
    'Non classé': 'bg-gray-100 text-gray-600 border-gray-300',
  };
  return <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${colors[cat] || colors['Non classé']}`}>{cat}</span>;
}

function GenreBadge({ genre }: { genre: string }) {
  return genre === 'feminin'
    ? <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-pink-100 text-pink-700 border border-pink-300">♀ Féminin</span>
    : <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-100 text-sky-700 border border-sky-300">♂ Masculin</span>;
}

export default function Saison() {
  const { equipes, setEquipes, matchs, setMatchs, saisonInfo, setSaisonInfo, joueursClub, setJoueursClub } = useData();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  // ===== Équipes =====
  const [editEq, setEditEq] = useState<Equipe | null>(null);
  const [showAddEq, setShowAddEq] = useState(false);
  const [eqName, setEqName] = useState(''); const [eqDiv, setEqDiv] = useState(''); const [eqJoueurs, setEqJoueurs] = useState('');

  // ===== Matchs =====
  const [editMatch, setEditMatch] = useState<MatchItem | null>(null);
  const [showAddMatch, setShowAddMatch] = useState(false);
  const [mDate, setMDate] = useState(''); const [mMatch, setMMatch] = useState(''); const [mLieu, setMLieu] = useState(''); const [mRes, setMRes] = useState('');

  // ===== Joueurs =====
  const [editJoueur, setEditJoueur] = useState<JoueurClub | null>(null);
  const [showAddJoueur, setShowAddJoueur] = useState(false);
  const [jNom, setJNom] = useState('');
  const [jPrenom, setJPrenom] = useState('');
  const [jDateN, setJDateN] = useState('');
  const [jGenre, setJGenre] = useState<'masculin' | 'feminin'>('masculin');
  const [jCat, setJCat] = useState<'Elite' | 'Honneur' | 'Promotion' | 'Non classé'>('Non classé');
  const [jPhoto, setJPhoto] = useState('');

  // ===== Année =====
  const [showEditAnnee, setShowEditAnnee] = useState(false);
  const [annee, setAnnee] = useState(saisonInfo.annee);

  // ===== Delete =====
  const [delId, setDelId] = useState<{ type: 'equipe' | 'match' | 'joueur'; id: string } | null>(null);

  // ===== Filtre joueurs =====
  const [filtreGenre, setFiltreGenre] = useState<'tous' | 'masculin' | 'feminin'>('tous');
  const [filtreCat, setFiltreCat] = useState<string>('tous');

  const joueursFiltres = joueursClub.filter(j => {
    if (filtreGenre !== 'tous' && j.genre !== filtreGenre) return false;
    if (filtreCat !== 'tous' && j.categorie !== filtreCat) return false;
    return true;
  });

  // ===== Handlers Équipes =====
  function openAddEq() { setEqName(''); setEqDiv(''); setEqJoueurs(''); setShowAddEq(true); }
  function openEditEq(eq: Equipe) { setEqName(eq.name); setEqDiv(eq.division); setEqJoueurs(eq.joueurs.join(', ')); setEditEq(eq); }
  function saveEq(e: React.FormEvent) { e.preventDefault();
    const data = { name: eqName, division: eqDiv, joueurs: eqJoueurs.split(',').map(s => s.trim()).filter(Boolean), resultats: '' };
    if (editEq) { setEquipes(equipes.map(eq => eq.id === editEq.id ? { ...eq, ...data } : eq)); setEditEq(null); }
    else { setEquipes([...equipes, { id: uid(), ...data }]); setShowAddEq(false); }
  }

  // ===== Handlers Matchs =====
  function openAddMatch() { setMDate(''); setMMatch(''); setMLieu(''); setMRes('À venir'); setShowAddMatch(true); }
  function openEditMatch(m: MatchItem) { setMDate(m.date); setMMatch(m.match); setMLieu(m.lieu); setMRes(m.resultat); setEditMatch(m); }
  function saveMatch(e: React.FormEvent) { e.preventDefault();
    const data = { date: mDate, match: mMatch, lieu: mLieu, resultat: mRes };
    if (editMatch) { setMatchs(matchs.map(m => m.id === editMatch.id ? { ...m, ...data } : m)); setEditMatch(null); }
    else { setMatchs([...matchs, { id: uid(), ...data }]); setShowAddMatch(false); }
  }

  // ===== Handlers Joueurs =====
  function openAddJoueur() { setJNom(''); setJPrenom(''); setJDateN(''); setJGenre('masculin'); setJCat('Non classé'); setJPhoto(''); setShowAddJoueur(true); }
  function openEditJoueur(j: JoueurClub) { setJNom(j.nom); setJPrenom(j.prenom); setJDateN(j.dateNaissance); setJGenre(j.genre); setJCat(j.categorie); setJPhoto(j.photo); setEditJoueur(j); }
  function saveJoueur(e: React.FormEvent) { e.preventDefault();
    const data: Omit<JoueurClub, 'id'> = { nom: jNom, prenom: jPrenom, dateNaissance: jDateN, genre: jGenre, categorie: jCat, photo: jPhoto };
    if (editJoueur) { setJoueursClub(joueursClub.map(j => j.id === editJoueur.id ? { ...j, ...data } : j)); setEditJoueur(null); }
    else { setJoueursClub([...joueursClub, { id: uid(), ...data }]); setShowAddJoueur(false); }
  }

  // ===== Année =====
  function saveAnnee(e: React.FormEvent) { e.preventDefault(); setSaisonInfo({ annee }); setShowEditAnnee(false); }

  // ===== Delete =====
  function handleDelete() {
    if (!delId) return;
    if (delId.type === 'equipe') setEquipes(equipes.filter(eq => eq.id !== delId.id));
    else if (delId.type === 'match') setMatchs(matchs.filter(m => m.id !== delId.id));
    else if (delId.type === 'joueur') setJoueursClub(joueursClub.filter(j => j.id !== delId.id));
    setDelId(null);
  }

  return (
    <section id="saison" className="py-16 px-4 sm:px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-3xl font-extrabold text-[#2c3e50] flex items-center gap-3">
            <span className="w-1.5 h-8 bg-[#1abc9c] rounded-full inline-block" /> Saison {saisonInfo.annee}
          </h2>
          {isAdmin && (
            <button onClick={() => { setAnnee(saisonInfo.annee); setShowEditAnnee(true); }} className="flex items-center gap-1 text-gray-400 hover:text-[#1abc9c] text-xs font-semibold transition-colors">
              <Settings size={14} /> Changer l'année
            </button>
          )}
        </div>
        <p className="text-gray-500 mb-10">Équipes, joueurs, calendriers et résultats</p>

        {/* ======================================== */}
        {/* ===== JOUEURS / JOUEUSES ===== */}
        {/* ======================================== */}
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-xl font-bold text-[#2c3e50] flex items-center gap-2">
            <Users size={20} className="text-[#1abc9c]" /> Joueurs & Joueuses
            <span className="text-sm text-gray-400 font-normal ml-1">({joueursClub.length})</span>
          </h3>
          <AddButton onClick={openAddJoueur} label="Ajouter un joueur" />
        </div>

        {/* Filtres */}
        <div className="flex flex-wrap gap-2 mb-6">
          <select value={filtreGenre} onChange={e => setFiltreGenre(e.target.value as typeof filtreGenre)}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-semibold bg-white focus:outline-none focus:ring-2 focus:ring-[#1abc9c]">
            <option value="tous">Tous genres</option>
            <option value="masculin">♂ Masculin</option>
            <option value="feminin">♀ Féminin</option>
          </select>
          <select value={filtreCat} onChange={e => setFiltreCat(e.target.value)}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-semibold bg-white focus:outline-none focus:ring-2 focus:ring-[#1abc9c]">
            <option value="tous">Toutes catégories</option>
            <option value="Elite">Elite</option>
            <option value="Honneur">Honneur</option>
            <option value="Promotion">Promotion</option>
            <option value="Non classé">Non classé</option>
          </select>
          <span className="text-xs text-gray-400 self-center ml-2">{joueursFiltres.length} résultat{joueursFiltres.length > 1 ? 's' : ''}</span>
        </div>

        {/* Grille joueurs */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 mb-14">
          {joueursFiltres.map(j => (
            <div key={j.id} className="bg-gray-50 rounded-xl border border-gray-100 overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1 relative group">
              {/* Admin actions */}
              <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <EditButton onClick={() => openEditJoueur(j)} />
                <DeleteButton onClick={() => setDelId({ type: 'joueur', id: j.id })} />
              </div>

              {/* Photo */}
              <div className="w-full aspect-square bg-gradient-to-br from-[#2c3e50] to-[#34495e] flex items-center justify-center overflow-hidden">
                {j.photo ? (
                  <img src={j.photo} alt={`${j.prenom} ${j.nom}`} className="w-full h-full object-cover" />
                ) : (
                  <div className="text-center">
                    <span className="text-4xl">{j.genre === 'feminin' ? '👩' : '👨'}</span>
                  </div>
                )}
              </div>

              {/* Infos */}
              <div className="p-3">
                <h4 className="font-bold text-[#2c3e50] text-sm leading-tight">{j.prenom}</h4>
                <p className="font-bold text-[#2c3e50] text-sm leading-tight uppercase">{j.nom}</p>
                {j.dateNaissance && (
                  <p className="text-[10px] text-gray-400 mt-1">Né{j.genre === 'feminin' ? 'e' : ''} le {j.dateNaissance}</p>
                )}
                <div className="flex flex-wrap gap-1 mt-2">
                  <GenreBadge genre={j.genre} />
                  <CategorieBadge cat={j.categorie} />
                </div>
              </div>
            </div>
          ))}
        </div>
        {joueursClub.length === 0 && (
          <div className="text-center py-10 mb-14 text-gray-400">
            <UserPlus size={40} className="mx-auto mb-2 opacity-30" />
            <p className="font-medium">Aucun joueur enregistré</p>
            {isAdmin && <p className="text-xs mt-1">Cliquez sur "Ajouter un joueur" pour commencer</p>}
          </div>
        )}
        {joueursClub.length > 0 && joueursFiltres.length === 0 && (
          <p className="text-gray-400 text-center py-8 mb-14">Aucun résultat pour ces filtres</p>
        )}

        {/* ======================================== */}
        {/* ===== ÉQUIPES ===== */}
        {/* ======================================== */}
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-xl font-bold text-[#2c3e50] flex items-center gap-2"><Users size={20} className="text-[#1abc9c]" /> Nos Équipes</h3>
          <AddButton onClick={openAddEq} label="Ajouter une équipe" />
        </div>
        <div className="grid md:grid-cols-3 gap-5 mb-12">
          {equipes.map((eq) => (
            <div key={eq.id} className="bg-gray-50 rounded-xl overflow-hidden border border-gray-100 hover:shadow-md transition-shadow relative group">
              <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <EditButton onClick={() => openEditEq(eq)} />
                <DeleteButton onClick={() => setDelId({ type: 'equipe', id: eq.id })} />
              </div>
              <div className="bg-[#1abc9c] px-5 py-3">
                <h4 className="text-white font-bold text-sm">{eq.name}</h4>
                <span className="text-white/70 text-xs">{eq.division}</span>
              </div>
              <div className="p-5">
                <div className="text-sm text-gray-600">{eq.joueurs.join(' · ')}</div>
              </div>
            </div>
          ))}
          {equipes.length === 0 && <p className="text-gray-400 col-span-3 text-center py-8">Aucune équipe</p>}
        </div>

        {/* ======================================== */}
        {/* ===== CALENDRIER ===== */}
        {/* ======================================== */}
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-xl font-bold text-[#2c3e50] flex items-center gap-2"><Calendar size={20} className="text-[#1abc9c]" /> Calendrier des Matchs</h3>
          <AddButton onClick={openAddMatch} label="Ajouter un match" />
        </div>
        <div className="bg-gray-50 rounded-xl overflow-hidden border border-gray-100">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="bg-[#2c3e50] text-white">
                <th className="px-5 py-3 text-left font-semibold">Date</th>
                <th className="px-5 py-3 text-left font-semibold">Match</th>
                <th className="px-5 py-3 text-left font-semibold">Lieu</th>
                <th className="px-5 py-3 text-left font-semibold">Résultat</th>
                <th className="px-5 py-3 text-center font-semibold">Actions</th>
              </tr></thead>
              <tbody>
                {matchs.map((m, i) => (
                  <tr key={m.id} className={`border-b border-gray-100 ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                    <td className="px-5 py-3 font-semibold text-[#1abc9c]">{m.date}</td>
                    <td className="px-5 py-3 text-[#2c3e50] font-medium">{m.match}</td>
                    <td className="px-5 py-3 text-gray-500">{m.lieu}</td>
                    <td className="px-5 py-3">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${m.resultat === 'À venir' ? 'bg-gray-200 text-gray-600' : 'bg-[#1abc9c]/15 text-[#1abc9c]'}`}>{m.resultat}</span>
                    </td>
                    <td className="px-5 py-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <EditButton onClick={() => openEditMatch(m)} />
                        <DeleteButton onClick={() => setDelId({ type: 'match', id: m.id })} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {matchs.length === 0 && <p className="text-gray-400 text-center py-8">Aucun match</p>}
        </div>
      </div>

      {/* ===== MODALS ===== */}

      {/* Modal Joueur */}
      <EditModal open={showAddJoueur || !!editJoueur} onClose={() => { setShowAddJoueur(false); setEditJoueur(null); }} title={editJoueur ? 'Modifier le joueur' : 'Ajouter un joueur / joueuse'}>
        <form onSubmit={saveJoueur} className="space-y-4">
          <div className="flex justify-center">
            <PhotoUpload photo={jPhoto} onChange={setJPhoto} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Prénom" value={jPrenom} onChange={setJPrenom} placeholder="Jean" required />
            <Field label="Nom" value={jNom} onChange={setJNom} placeholder="DUPONT" required />
          </div>

          <Field label="Date de naissance" value={jDateN} onChange={setJDateN} placeholder="15/03/1985" />

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-semibold text-[#2c3e50] mb-1">Genre</label>
              <select value={jGenre} onChange={e => setJGenre(e.target.value as typeof jGenre)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c]">
                <option value="masculin">♂ Masculin</option>
                <option value="feminin">♀ Féminin</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-[#2c3e50] mb-1">Catégorie</label>
              <select value={jCat} onChange={e => setJCat(e.target.value as typeof jCat)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c]">
                <option value="Elite">🏆 Elite</option>
                <option value="Honneur">🥇 Honneur</option>
                <option value="Promotion">🥈 Promotion</option>
                <option value="Non classé">— Non classé</option>
              </select>
            </div>
          </div>

          <SaveButton label={editJoueur ? 'Enregistrer' : 'Ajouter le joueur'} />
        </form>
      </EditModal>

      {/* Modal Équipe */}
      <EditModal open={showAddEq || !!editEq} onClose={() => { setShowAddEq(false); setEditEq(null); }} title={editEq ? "Modifier l'équipe" : 'Nouvelle équipe'}>
        <form onSubmit={saveEq} className="space-y-3">
          <Field label="Nom de l'équipe" value={eqName} onChange={setEqName} placeholder="Équipe 1 – CDC Masculin" required />
          <Field label="Division" value={eqDiv} onChange={setEqDiv} placeholder="Division 1" required />
          <Field label="Joueurs (séparés par des virgules)" value={eqJoueurs} onChange={setEqJoueurs} placeholder="J-P. Martin, M. Dupont, ..." required />
          <SaveButton />
        </form>
      </EditModal>

      {/* Modal Match */}
      <EditModal open={showAddMatch || !!editMatch} onClose={() => { setShowAddMatch(false); setEditMatch(null); }} title={editMatch ? 'Modifier le match' : 'Nouveau match'}>
        <form onSubmit={saveMatch} className="space-y-3">
          <Field label="Date" value={mDate} onChange={setMDate} placeholder="12 Jan" required />
          <Field label="Match" value={mMatch} onChange={setMMatch} placeholder="Naintré vs Châtellerault" required />
          <Field label="Lieu" value={mLieu} onChange={setMLieu} placeholder="Domicile / Extérieur" required />
          <Field label="Résultat" value={mRes} onChange={setMRes} placeholder="3-1 ou À venir" required />
          <SaveButton />
        </form>
      </EditModal>

      {/* Modal Année */}
      <EditModal open={showEditAnnee} onClose={() => setShowEditAnnee(false)} title="Changer l'année de saison">
        <form onSubmit={saveAnnee} className="space-y-3">
          <Field label="Année de la saison" value={annee} onChange={setAnnee} placeholder="2024–2025" required />
          <SaveButton />
        </form>
      </EditModal>

      {delId && <ConfirmDelete message="Supprimer cet élément ?" onConfirm={handleDelete} onCancel={() => setDelId(null)} />}
    </section>
  );
}
