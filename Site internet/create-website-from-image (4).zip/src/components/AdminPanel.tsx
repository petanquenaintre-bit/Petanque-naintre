import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Shield,
  UserCheck,
  UserX,
  Trash2,
  Clock,
  CheckCircle,
  XCircle,
  Users,
  AlertTriangle,
  RefreshCw,
  LogIn,
  BarChart3,
  User,
} from 'lucide-react';

export default function AdminPanel() {
  const { user, getAllUsers, approveUser, rejectUser, deleteUser, getPendingCount, getConnexionStats } = useAuth();
  const [refreshKey, setRefreshKey] = useState(0);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  // Seul l'admin voit ce panneau
  if (!user || user.role !== 'admin') return null;

  const allUsers = getAllUsers();
  const pendingCount = getPendingCount();

  const filteredUsers = allUsers.filter((u) => {
    if (u.id === 'admin-001') return false; // Ne pas s'afficher soi-même
    if (filter === 'all') return true;
    return u.status === filter;
  });

  function handleApprove(id: string) {
    approveUser(id);
    setRefreshKey((k) => k + 1);
  }

  function handleReject(id: string) {
    rejectUser(id);
    setRefreshKey((k) => k + 1);
  }

  function handleDelete(id: string) {
    deleteUser(id);
    setConfirmDelete(null);
    setRefreshKey((k) => k + 1);
  }

  function getStatusBadge(status: string) {
    switch (status) {
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 px-2.5 py-1 rounded-full text-xs font-bold">
            <Clock size={12} />
            En attente
          </span>
        );
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1 bg-green-100 text-green-700 px-2.5 py-1 rounded-full text-xs font-bold">
            <CheckCircle size={12} />
            Approuvé
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 bg-red-100 text-red-700 px-2.5 py-1 rounded-full text-xs font-bold">
            <XCircle size={12} />
            Refusé
          </span>
        );
      default:
        return null;
    }
  }

  // force re-render
  void refreshKey;

  return (
    <section id="admin" className="py-16 px-4 sm:px-6 bg-white border-t-4 border-[#e74c3c]">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h2 className="text-3xl font-extrabold text-[#2c3e50] flex items-center gap-3">
              <Shield size={28} className="text-[#e74c3c]" />
              Panneau d'Administration
            </h2>
            <p className="text-gray-500 mt-1">Gérez les demandes d'inscription et les membres</p>
          </div>
          <button
            onClick={() => setRefreshKey((k) => k + 1)}
            className="flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors self-start"
          >
            <RefreshCw size={14} />
            Actualiser
          </button>
        </div>

        {/* Stats cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          <div className="bg-gray-50 rounded-xl p-4 border border-gray-100 text-center">
            <Users size={22} className="text-[#3498db] mx-auto mb-1" />
            <div className="text-2xl font-extrabold text-[#2c3e50]">{allUsers.length - 1}</div>
            <div className="text-xs text-gray-500">Total membres</div>
          </div>
          <div
            className={`rounded-xl p-4 border text-center cursor-pointer transition-colors ${
              filter === 'pending' ? 'bg-amber-50 border-amber-300' : 'bg-gray-50 border-gray-100 hover:bg-amber-50'
            }`}
            onClick={() => setFilter(filter === 'pending' ? 'all' : 'pending')}
          >
            <Clock size={22} className="text-amber-500 mx-auto mb-1" />
            <div className="text-2xl font-extrabold text-[#2c3e50]">{pendingCount}</div>
            <div className="text-xs text-gray-500">En attente</div>
          </div>
          <div
            className={`rounded-xl p-4 border text-center cursor-pointer transition-colors ${
              filter === 'approved' ? 'bg-green-50 border-green-300' : 'bg-gray-50 border-gray-100 hover:bg-green-50'
            }`}
            onClick={() => setFilter(filter === 'approved' ? 'all' : 'approved')}
          >
            <CheckCircle size={22} className="text-green-500 mx-auto mb-1" />
            <div className="text-2xl font-extrabold text-[#2c3e50]">
              {allUsers.filter((u) => u.status === 'approved' && u.id !== 'admin-001').length}
            </div>
            <div className="text-xs text-gray-500">Approuvés</div>
          </div>
          <div
            className={`rounded-xl p-4 border text-center cursor-pointer transition-colors ${
              filter === 'rejected' ? 'bg-red-50 border-red-300' : 'bg-gray-50 border-gray-100 hover:bg-red-50'
            }`}
            onClick={() => setFilter(filter === 'rejected' ? 'all' : 'rejected')}
          >
            <XCircle size={22} className="text-red-500 mx-auto mb-1" />
            <div className="text-2xl font-extrabold text-[#2c3e50]">
              {allUsers.filter((u) => u.status === 'rejected').length}
            </div>
            <div className="text-xs text-gray-500">Refusés</div>
          </div>
        </div>

        {/* ===== COMPTEUR CONNEXIONS ===== */}
        {(() => {
          const stats = getConnexionStats();
          const anneesTriees = Object.keys(stats.parAnnee).sort((a, b) => b.localeCompare(a));
          const derniers = stats.logs.slice(0, 10);
          return (
            <div className="bg-gradient-to-br from-[#2c3e50] to-[#34495e] rounded-xl p-6 mb-8 text-white">
              <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                <BarChart3 size={20} className="text-[#1abc9c]" />
                Compteur de connexions
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6">
                {/* Total */}
                <div className="bg-white/10 rounded-xl p-4 text-center">
                  <LogIn size={22} className="text-[#1abc9c] mx-auto mb-1" />
                  <div className="text-3xl font-extrabold">{stats.total}</div>
                  <div className="text-xs text-gray-300">Connexions totales</div>
                </div>
                {/* Par année */}
                {anneesTriees.map(annee => (
                  <div key={annee} className="bg-white/10 rounded-xl p-4 text-center">
                    <div className="text-[#1abc9c] text-xs font-bold mb-1">📅 {annee}</div>
                    <div className="text-3xl font-extrabold">{stats.parAnnee[annee]}</div>
                    <div className="text-xs text-gray-300">Connexions</div>
                  </div>
                ))}
              </div>

              {/* Dernières connexions */}
              {derniers.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-gray-300 mb-3">🕐 Dernières connexions</h4>
                  <div className="space-y-1.5">
                    {derniers.map((log, i) => (
                      <div key={i} className="flex items-center gap-3 bg-white/5 rounded-lg px-3 py-2 text-sm">
                        <User size={14} className="text-[#1abc9c] shrink-0" />
                        <span className="font-semibold">{log.pseudo}</span>
                        <span className="text-gray-400 text-xs ml-auto">{log.date} à {log.heure}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {stats.total === 0 && (
                <p className="text-gray-400 text-center text-sm">Aucune connexion enregistrée</p>
              )}
            </div>
          );
        })()}

        {/* Alerte demandes en attente */}
        {pendingCount > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 flex items-center gap-3">
            <AlertTriangle size={20} className="text-amber-600 shrink-0" />
            <p className="text-amber-800 text-sm font-medium">
              <strong>{pendingCount} demande{pendingCount > 1 ? 's' : ''}</strong> d'inscription en attente de validation.
            </p>
            <button
              onClick={() => setFilter('pending')}
              className="ml-auto bg-amber-500 hover:bg-amber-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-colors shrink-0"
            >
              Voir
            </button>
          </div>
        )}

        {/* Filter tabs */}
        <div className="flex gap-2 mb-6 flex-wrap">
          {(['all', 'pending', 'approved', 'rejected'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
                filter === f
                  ? 'bg-[#2c3e50] text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {f === 'all' && 'Tous'}
              {f === 'pending' && '⏳ En attente'}
              {f === 'approved' && '✅ Approuvés'}
              {f === 'rejected' && '❌ Refusés'}
            </button>
          ))}
        </div>

        {/* User list */}
        {filteredUsers.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <Users size={48} className="mx-auto mb-3 opacity-30" />
            <p className="font-medium">Aucun membre dans cette catégorie</p>
            <p className="text-xs mt-1">
              {filter === 'pending' && "Pas de demande en attente pour le moment."}
              {filter === 'approved' && "Aucun membre approuvé."}
              {filter === 'rejected' && "Aucun membre refusé."}
              {filter === 'all' && "Aucun membre inscrit pour le moment."}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredUsers.map((u) => (
              <div
                key={u.id}
                className={`bg-white rounded-xl border p-5 transition-all hover:shadow-md ${
                  u.status === 'pending'
                    ? 'border-amber-200 bg-amber-50/30'
                    : u.status === 'rejected'
                    ? 'border-red-100 bg-red-50/20'
                    : 'border-gray-100'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  {/* User info */}
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-[#1abc9c]/10 rounded-full flex items-center justify-center text-xl shrink-0">
                      {u.avatar}
                    </div>
                    <div>
                      <div className="font-bold text-[#2c3e50]">
                        {u.prenom} {u.nom}
                      </div>
                      <div className="text-sm text-gray-500">
                        @{u.pseudo} · {u.email}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        {getStatusBadge(u.status)}
                        <span className="text-xs text-gray-400">
                          Inscrit le {u.dateInscription}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    {u.status === 'pending' && (
                      <>
                        <button
                          onClick={() => handleApprove(u.id)}
                          className="flex items-center gap-1.5 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-xs font-bold transition-colors"
                        >
                          <UserCheck size={14} />
                          Approuver
                        </button>
                        <button
                          onClick={() => handleReject(u.id)}
                          className="flex items-center gap-1.5 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-xs font-bold transition-colors"
                        >
                          <UserX size={14} />
                          Refuser
                        </button>
                      </>
                    )}
                    {u.status === 'approved' && (
                      <button
                        onClick={() => handleReject(u.id)}
                        className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-white px-3 py-2 rounded-lg text-xs font-bold transition-colors"
                      >
                        <UserX size={14} />
                        Suspendre
                      </button>
                    )}
                    {u.status === 'rejected' && (
                      <button
                        onClick={() => handleApprove(u.id)}
                        className="flex items-center gap-1.5 bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded-lg text-xs font-bold transition-colors"
                      >
                        <UserCheck size={14} />
                        Réactiver
                      </button>
                    )}

                    {/* Delete */}
                    {confirmDelete === u.id ? (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleDelete(u.id)}
                          className="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-lg text-xs font-bold transition-colors"
                        >
                          Confirmer
                        </button>
                        <button
                          onClick={() => setConfirmDelete(null)}
                          className="bg-gray-300 hover:bg-gray-400 text-gray-700 px-3 py-2 rounded-lg text-xs font-bold transition-colors"
                        >
                          Annuler
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setConfirmDelete(u.id)}
                        className="flex items-center gap-1 text-gray-400 hover:text-red-500 hover:bg-red-50 p-2 rounded-lg transition-colors"
                        title="Supprimer"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
