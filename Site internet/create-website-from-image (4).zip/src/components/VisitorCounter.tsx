import { useState, useEffect } from 'react';
import { Eye, Users, TrendingUp } from 'lucide-react';

interface VisitorStats {
  total: number;
  parAnnee: Record<string, number>;
  aujourdhui: number;
  dateAujourdhui: string;
  enLigne: number;
  dernierePing: number;
}

function getStats(): VisitorStats {
  try {
    return JSON.parse(localStorage.getItem('pn_visitor_stats') || 'null') || createDefault();
  } catch {
    return createDefault();
  }
}

function createDefault(): VisitorStats {
  return {
    total: 0,
    parAnnee: {},
    aujourdhui: 0,
    dateAujourdhui: new Date().toLocaleDateString('fr-FR'),
    enLigne: 0,
    dernierePing: Date.now(),
  };
}

function saveStats(stats: VisitorStats) {
  localStorage.setItem('pn_visitor_stats', JSON.stringify(stats));
}

// Enregistrer une visite (appelé une seule fois au chargement)
function registerVisit() {
  const stats = getStats();
  const today = new Date().toLocaleDateString('fr-FR');
  const year = new Date().getFullYear().toString();

  // Vérifier si déjà compté aujourd'hui dans cette session
  const sessionCounted = sessionStorage.getItem('pn_visit_counted');
  if (!sessionCounted) {
    stats.total += 1;
    stats.parAnnee[year] = (stats.parAnnee[year] || 0) + 1;

    if (stats.dateAujourdhui === today) {
      stats.aujourdhui += 1;
    } else {
      stats.dateAujourdhui = today;
      stats.aujourdhui = 1;
    }

    sessionStorage.setItem('pn_visit_counted', 'true');
  }

  // Mettre à jour "en ligne"
  stats.enLigne = 1;
  stats.dernierePing = Date.now();

  saveStats(stats);
  return stats;
}

// Ping "en ligne" toutes les 30 secondes
function pingOnline() {
  const stats = getStats();
  stats.dernierePing = Date.now();
  // Compter comme "en ligne" si le dernier ping est < 60 secondes
  const elapsed = Date.now() - stats.dernierePing;
  stats.enLigne = elapsed < 60000 ? Math.max(1, stats.enLigne) : 1;
  saveStats(stats);
}

// ===== Composant Compteur Navbar (petit) =====
export function NavbarCounter() {
  const [stats, setStats] = useState<VisitorStats>(createDefault);

  useEffect(() => {
    const s = registerVisit();
    setStats(s);

    const interval = setInterval(() => {
      pingOnline();
      setStats(getStats());
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="hidden md:flex items-center gap-3 text-white/70 text-xs">
      <div className="flex items-center gap-1" title="Visiteurs aujourd'hui">
        <Eye size={13} className="text-[#1abc9c]" />
        <span className="font-bold text-white">{stats.aujourdhui}</span>
        <span>aujourd'hui</span>
      </div>
      <div className="w-px h-4 bg-white/20" />
      <div className="flex items-center gap-1" title="Total visiteurs">
        <TrendingUp size={13} className="text-[#f39c12]" />
        <span className="font-bold text-white">{stats.total}</span>
        <span>total</span>
      </div>
    </div>
  );
}

// ===== Composant Compteur Footer (détaillé) =====
export function FooterCounter() {
  const [stats, setStats] = useState<VisitorStats>(createDefault);

  useEffect(() => {
    setStats(getStats());
    const interval = setInterval(() => setStats(getStats()), 30000);
    return () => clearInterval(interval);
  }, []);

  const anneesTriees = Object.keys(stats.parAnnee).sort((a, b) => b.localeCompare(a));

  return (
    <div className="bg-white/5 rounded-xl p-5 border border-white/10">
      <h4 className="font-bold text-sm mb-4 text-[#1abc9c] flex items-center gap-2">
        <Users size={16} />
        COMPTEUR DE VISITES
      </h4>

      <div className="grid grid-cols-2 gap-3 mb-4">
        {/* Aujourd'hui */}
        <div className="bg-white/5 rounded-lg p-3 text-center">
          <Eye size={18} className="text-[#1abc9c] mx-auto mb-1" />
          <div className="text-2xl font-extrabold text-white">{stats.aujourdhui}</div>
          <div className="text-[10px] text-gray-400">Aujourd'hui</div>
        </div>
        {/* Total */}
        <div className="bg-white/5 rounded-lg p-3 text-center">
          <TrendingUp size={18} className="text-[#f39c12] mx-auto mb-1" />
          <div className="text-2xl font-extrabold text-white">{stats.total}</div>
          <div className="text-[10px] text-gray-400">Total visites</div>
        </div>
      </div>

      {/* Par année */}
      {anneesTriees.length > 0 && (
        <div className="space-y-1.5">
          {anneesTriees.map(annee => (
            <div key={annee} className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-2">
              <span className="text-xs text-gray-400">📅 {annee}</span>
              <span className="text-sm font-bold text-white">{stats.parAnnee[annee]} <span className="text-gray-400 font-normal text-xs">visites</span></span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ===== Barre flottante en bas (visible par tous) =====
export default function VisitorBar() {
  const [stats, setStats] = useState<VisitorStats>(createDefault);

  useEffect(() => {
    const s = registerVisit();
    setStats(s);
    const interval = setInterval(() => {
      setStats(getStats());
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#2c3e50]/95 backdrop-blur-sm border-t border-[#1abc9c]/20 py-2 px-4">
      <div className="max-w-7xl mx-auto flex items-center justify-center gap-6 text-white text-xs">
        <div className="flex items-center gap-1.5">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500"></span>
          </span>
          <span className="text-green-400 font-semibold">En ligne</span>
        </div>
        <div className="w-px h-4 bg-white/20" />
        <div className="flex items-center gap-1.5">
          <Eye size={13} className="text-[#1abc9c]" />
          <span><span className="font-bold text-white text-sm">{stats.aujourdhui}</span> <span className="text-gray-400">aujourd'hui</span></span>
        </div>
        <div className="w-px h-4 bg-white/20" />
        <div className="flex items-center gap-1.5">
          <TrendingUp size={13} className="text-[#f39c12]" />
          <span><span className="font-bold text-white text-sm">{stats.total}</span> <span className="text-gray-400">visites au total</span></span>
        </div>
        {Object.keys(stats.parAnnee).length > 0 && (
          <>
            <div className="hidden sm:block w-px h-4 bg-white/20" />
            <div className="hidden sm:flex items-center gap-2">
              {Object.keys(stats.parAnnee).sort((a, b) => b.localeCompare(a)).map(annee => (
                <span key={annee} className="bg-white/10 px-2 py-0.5 rounded-full text-[10px]">
                  {annee}: <span className="font-bold">{stats.parAnnee[annee]}</span>
                </span>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
