import { useState } from 'react';
import { Camera, Play } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { MediaItem } from '../context/DataContext';
import { AddButton, EditButton, DeleteButton, EditModal, Field, SaveButton, ConfirmDelete } from './AdminActions';

const uid = () => Date.now().toString() + Math.random().toString(36).slice(2, 6);
const colors = ['from-[#1abc9c] to-[#16a085]', 'from-[#2c3e50] to-[#34495e]', 'from-[#3498db] to-[#2980b9]', 'from-[#e74c3c] to-[#c0392b]', 'from-[#f39c12] to-[#d68910]', 'from-[#9b59b6] to-[#8e44ad]'];

export default function Medias() {
  const { medias, setMedias } = useData();
  const [editM, setEditM] = useState<MediaItem | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [delId, setDelId] = useState<string | null>(null);

  const [mTitle, setMTitle] = useState(''); const [mType, setMType] = useState<'photo' | 'video'>('photo'); const [mCount, setMCount] = useState('');

  function openAdd() { setMTitle(''); setMType('photo'); setMCount(''); setShowAdd(true); }
  function openEdit(m: MediaItem) { setMTitle(m.title); setMType(m.type); setMCount(m.count.toString()); setEditM(m); }

  function saveMedia(e: React.FormEvent) { e.preventDefault();
    const data = { title: mTitle, type: mType, count: parseInt(mCount) || 0 };
    if (editM) { setMedias(medias.map(m => m.id === editM.id ? { ...m, ...data } : m)); setEditM(null); }
    else { setMedias([...medias, { id: uid(), ...data }]); setShowAdd(false); }
  }

  return (
    <section id="medias" className="py-16 px-4 sm:px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-3xl font-extrabold text-[#2c3e50] flex items-center gap-3">
            <span className="w-1.5 h-8 bg-[#1abc9c] rounded-full inline-block" /> Médias
          </h2>
          <AddButton onClick={openAdd} label="Ajouter un album" />
        </div>
        <p className="text-gray-500 mb-10">Photos et vidéos du club</p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {medias.map((item, i) => (
            <div key={item.id} className="group relative overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer hover:-translate-y-1">
              <div className={`bg-gradient-to-br ${colors[i % colors.length]} h-48 flex items-center justify-center`}>
                {item.type === 'photo' ? <Camera size={48} className="text-white/30" /> : <Play size={48} className="text-white/30" />}
              </div>
              <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <EditButton onClick={() => openEdit(item)} />
                <DeleteButton onClick={() => setDelId(item.id)} />
              </div>
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                  {item.type === 'photo' ? <Camera size={32} className="text-white" /> : <Play size={32} className="text-white" />}
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                <h3 className="text-white font-bold text-sm">{item.title}</h3>
                <p className="text-white/70 text-xs mt-1">{item.count} {item.type === 'photo' ? 'photos' : 'vidéos'}</p>
              </div>
            </div>
          ))}
        </div>
        {medias.length === 0 && <p className="text-gray-400 text-center py-12">Aucun média</p>}
      </div>

      <EditModal open={showAdd || !!editM} onClose={() => { setShowAdd(false); setEditM(null); }} title={editM ? "Modifier l'album" : 'Nouvel album'}>
        <form onSubmit={saveMedia} className="space-y-3">
          <Field label="Titre" value={mTitle} onChange={setMTitle} placeholder="Concours Doublettes 2025" required />
          <div>
            <label className="block text-sm font-semibold text-[#2c3e50] mb-1">Type</label>
            <select value={mType} onChange={(e) => setMType(e.target.value as 'photo' | 'video')} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c]">
              <option value="photo">📷 Photos</option>
              <option value="video">🎬 Vidéos</option>
            </select>
          </div>
          <Field label="Nombre" value={mCount} onChange={setMCount} type="number" placeholder="24" required />
          <SaveButton />
        </form>
      </EditModal>

      {delId && <ConfirmDelete message="Supprimer cet album ?" onConfirm={() => { setMedias(medias.filter(m => m.id !== delId)); setDelId(null); }} onCancel={() => setDelId(null)} />}
    </section>
  );
}
