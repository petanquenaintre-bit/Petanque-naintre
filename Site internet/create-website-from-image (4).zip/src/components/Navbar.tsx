import { useState, useRef, useEffect } from 'react';
import {
  Home,
  Newspaper,
  Trophy,
  Calendar,
  Award,
  Camera,
  Handshake,
  HelpCircle,
  CreditCard,
  MessageSquare,
  LogIn,
  LogOut,
  Menu,
  X,
  User,
  ChevronDown,
  Settings,
  Shield,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { icon: Home, label: 'ACCUEIL', href: '#accueil', active: true },
  { icon: Newspaper, label: 'ACTUALITÉS', href: '#actualites' },
  { icon: Trophy, label: 'CLUB', href: '#club' },
  { icon: Calendar, label: 'SAISON', href: '#saison' },
  { icon: Award, label: 'SCORES & CLASSEMENTS', href: '#scores' },
  { icon: Camera, label: 'MÉDIAS', href: '#medias' },
  { icon: Handshake, label: 'PARTENAIRES', href: '#partenaires' },
  { icon: HelpCircle, label: 'FAQ', href: '#faq' },
  { icon: CreditCard, label: 'LICENCES', href: '#licences' },
  { icon: MessageSquare, label: 'FORUM', href: '#forum' },
];

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const { user, logout, setShowAuthModal, setAuthTab, getPendingCount } = useAuth();
  const pendingCount = user?.role === 'admin' ? getPendingCount() : 0;
  const userMenuRef = useRef<HTMLDivElement>(null);

  // Fermer le menu user au clic extérieur
  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setUserMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  function openLogin() {
    setAuthTab('login');
    setShowAuthModal(true);
    setMobileOpen(false);
  }

  function openRegister() {
    setAuthTab('register');
    setShowAuthModal(true);
    setMobileOpen(false);
  }

  function handleLogout() {
    logout();
    setUserMenuOpen(false);
    setMobileOpen(false);
  }

  return (
    <nav className="bg-[#2c3e50] text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo + Brand */}
          <a href="#accueil" className="flex items-center gap-3 shrink-0">
            <img
              src="/images/logo.png"
              alt="Logo Pétanque Naintréenne"
              className="w-10 h-10 rounded-full object-cover border-2 border-white"
            />
            <div className="leading-tight">
              <div className="font-bold text-sm tracking-wide">PÉTANQUE</div>
              <div className="text-[#1abc9c] text-xs font-semibold">NAINTRÉENNE</div>
            </div>
          </a>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className={`flex items-center gap-1.5 px-2.5 py-2 text-xs font-medium rounded transition-colors hover:bg-[#1abc9c]/20 ${
                  item.active
                    ? 'text-[#1abc9c] border-b-2 border-[#1abc9c]'
                    : 'text-gray-200'
                }`}
              >
                <item.icon size={14} />
                <span>{item.label}</span>
              </a>
            ))}
          </div>

          {/* Desktop: User area */}
          <div className="hidden lg:flex items-center gap-2">
            {user ? (
              /* Utilisateur connecté */
              <>
              <div className="relative" ref={userMenuRef}>
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="relative flex items-center gap-2 bg-[#1abc9c] hover:bg-[#16a085] text-white px-3 py-2 rounded-lg font-semibold text-sm transition-colors"
                >
                  {pendingCount > 0 && (
                    <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center animate-pulse">
                      {pendingCount}
                    </span>
                  )}
                  <span className="w-7 h-7 bg-white/20 rounded-full flex items-center justify-center text-base">
                    {user.avatar}
                  </span>
                  <span className="max-w-[100px] truncate">{user.pseudo}</span>
                  <ChevronDown
                    size={14}
                    className={`transition-transform ${userMenuOpen ? 'rotate-180' : ''}`}
                  />
                </button>

                {/* Dropdown */}
                {userMenuOpen && (
                  <div className="absolute right-0 top-full mt-2 w-64 bg-white rounded-xl shadow-2xl border border-gray-100 overflow-hidden z-50">
                    {/* User info header */}
                    <div className="bg-gray-50 px-4 py-3 border-b border-gray-100">
                      <div className="flex items-center gap-3">
                        <span className="w-10 h-10 bg-[#1abc9c]/10 rounded-full flex items-center justify-center text-xl">
                          {user.avatar}
                        </span>
                        <div>
                          <div className="font-bold text-[#2c3e50] text-sm">
                            {user.prenom} {user.nom}
                          </div>
                          <div className="text-gray-400 text-xs">@{user.pseudo}</div>
                          <div className="text-[#1abc9c] text-[10px] font-semibold uppercase mt-0.5">
                            {user.role}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="py-1">
                      <a
                        href="#profil"
                        onClick={() => setUserMenuOpen(false)}
                        className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                      >
                        <User size={16} className="text-gray-400" />
                        Mon Profil
                      </a>
                      <a
                        href="#profil"
                        onClick={() => setUserMenuOpen(false)}
                        className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                      >
                        <Settings size={16} className="text-gray-400" />
                        Paramètres
                      </a>
                      {user.role === 'admin' && (
                        <a
                          href="#admin"
                          onClick={() => setUserMenuOpen(false)}
                          className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                        >
                          <Shield size={16} className="text-[#e74c3c]" />
                          Administration
                          {pendingCount > 0 && (
                            <span className="ml-auto bg-red-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                              {pendingCount}
                            </span>
                          )}
                        </a>
                      )}
                    </div>

                    <div className="border-t border-gray-100 py-1">
                      <button
                        onClick={handleLogout}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors"
                      >
                        <LogOut size={16} />
                        Se déconnecter
                      </button>
                    </div>
                  </div>
                )}
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 bg-red-500/80 hover:bg-red-600 text-white px-3 py-2 rounded-lg font-semibold text-sm transition-colors"
                title="Se déconnecter"
              >
                <LogOut size={16} />
                Déconnexion
              </button>
              </>
            ) : (
              /* Non connecté */
              <button
                onClick={openLogin}
                className="flex items-center gap-2 bg-[#1abc9c] hover:bg-[#16a085] text-white px-4 py-2 rounded font-bold text-sm transition-colors"
              >
                <LogIn size={16} />
                CONNEXION
              </button>
            )}
          </div>

          {/* Bouton Déconnexion toujours visible quand connecté */}
          {user && (
            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg font-bold text-xs transition-colors"
            >
              <LogOut size={14} />
              <span className="hidden sm:inline">Déconnexion</span>
            </button>
          )}

          {/* Mobile Toggle */}
          <button
            className="lg:hidden text-white p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-[#34495e] border-t border-[#1abc9c]/30">
          <div className="px-4 py-2 space-y-1">
            {/* User info in mobile */}
            {user && (
              <div className="flex items-center gap-3 px-3 py-3 mb-2 bg-[#2c3e50] rounded-lg">
                <span className="w-10 h-10 bg-[#1abc9c]/20 rounded-full flex items-center justify-center text-xl">
                  {user.avatar}
                </span>
                <div>
                  <div className="text-white font-semibold text-sm">
                    {user.prenom} {user.nom}
                  </div>
                  <div className="text-gray-400 text-xs">@{user.pseudo}</div>
                </div>
              </div>
            )}

            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded transition-colors hover:bg-[#1abc9c]/20 ${
                  item.active ? 'text-[#1abc9c]' : 'text-gray-200'
                }`}
              >
                <item.icon size={16} />
                <span>{item.label}</span>
              </a>
            ))}

            {user ? (
              <>
                <a
                  href="#profil"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 text-sm font-medium text-gray-200 rounded hover:bg-[#1abc9c]/20 transition-colors"
                >
                  <User size={16} />
                  Mon Profil
                </a>
                {user.role === 'admin' && (
                  <a
                    href="#admin"
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center gap-3 px-3 py-2.5 text-sm font-medium text-gray-200 rounded hover:bg-[#1abc9c]/20 transition-colors"
                  >
                    <Shield size={16} className="text-[#e74c3c]" />
                    Administration
                    {pendingCount > 0 && (
                      <span className="ml-auto bg-red-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                        {pendingCount}
                      </span>
                    )}
                  </a>
                )}
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 bg-red-500/80 hover:bg-red-600 text-white px-3 py-2.5 rounded font-bold text-sm transition-colors mt-2"
                >
                  <LogOut size={16} />
                  Se déconnecter
                </button>
              </>
            ) : (
              <div className="space-y-2 mt-2">
                <button
                  onClick={openLogin}
                  className="w-full flex items-center gap-3 bg-[#1abc9c] hover:bg-[#16a085] text-white px-3 py-2.5 rounded font-bold text-sm transition-colors"
                >
                  <LogIn size={16} />
                  CONNEXION
                </button>
                <button
                  onClick={openRegister}
                  className="w-full flex items-center gap-3 border border-[#1abc9c] text-[#1abc9c] hover:bg-[#1abc9c]/10 px-3 py-2.5 rounded font-bold text-sm transition-colors"
                >
                  <User size={16} />
                  CRÉER UN COMPTE
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
