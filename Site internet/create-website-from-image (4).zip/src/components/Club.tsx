import { useState, useRef } from 'react';
import { User, Mail, Phone, MapPin, Upload, X, Scale } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { Dirigeant, Arbitre } from '../context/DataContext';
import { AddButton, EditButton, DeleteButton, EditModal, Field, SaveButton, ConfirmDelete } from './AdminActions';
import { useAuth } from '../context/AuthContext';

const uid = () => Date.now().toString() + Math.random().toString(36).slice(2, 6);

// ===== Photo Upload =====
function PhotoUploadField({ photo, onChange }: { photo: string; onChange: (v: string) => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) { alert('Max 2 Mo'); return; }
    const reader = new FileReader();
    reader.onload = () => { if (typeof reader.result === 'string') onChange(reader.result); };
    reader.readAsDataURL(file);
  }
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="w-24 h-24 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden cursor-pointer hover:border-[#1abc9c] transition-colors bg-gray-50"
        onClick={() => inputRef.current?.click()}>
        {photo ? <img src={photo} alt="" className="w-full h-full object-cover rounded-full" /> : (
          <div className="text-center"><Upload size={20} className="text-gray-400 mx-auto" /><span className="text-[10px] text-gray-400">Photo</span></div>
        )}
      </div>
      <input ref={inputRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
      {photo && <button type="button" onClick={() => onChange('')} className="text-xs text-red-500 hover:text-red-700 flex items-center gap-1"><X size={12} /> Supprimer</button>}
    </div>
  );
}

// ===== Couleurs/Emojis =====
function getRoleColor(role: string): string {
  const r = role.toLowerCase();
  if (r.includes('président') && !r.includes('vice')) return 'from-[#2c3e50] to-[#34495e]';
  if (r.includes('vice')) return 'from-[#1abc9c] to-[#16a085]';
  if (r.includes('secrétaire')) return 'from-[#3498db] to-[#2980b9]';
  if (r.includes('trésor')) return 'from-[#f39c12] to-[#d68910]';
  return 'from-[#9b59b6] to-[#8e44ad]';
}
function getRoleEmoji(role: string): string {
  const r = role.toLowerCase();
  if (r.includes('président') && !r.includes('vice')) return '👑';
  if (r.includes('vice')) return '⭐';
  if (r.includes('secrétaire')) return '📋';
  if (r.includes('trésor')) return '💰';
  return '👤';
}
function getNiveauColor(n: string): string {
  if (n === 'National') return 'bg-yellow-100 text-yellow-800 border-yellow-300';
  if (n === 'Régional') return 'bg-blue-100 text-blue-800 border-blue-300';
  if (n === 'Départemental') return 'bg-green-100 text-green-800 border-green-300';
  return 'bg-gray-100 text-gray-600 border-gray-300';
}
function getArbitreGradient(n: string): string {
  if (n === 'National') return 'from-yellow-600 to-yellow-800';
  if (n === 'Régional') return 'from-blue-600 to-blue-800';
  if (n === 'Départemental') return 'from-green-600 to-green-800';
  return 'from-[#e74c3c] to-[#c0392b]';
}

export default function Club() {
  const { dirigeants, setDirigeants, arbitres, setArbitres, clubInfo, setClubInfo } = useData();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  // Dirigeants
  const [editD, setEditD] = useState<Dirigeant | null>(null);
  const [showAddD, setShowAddD] = useState(false);
  const [dRole, setDRole] = useState(''); const [dName, setDName] = useState(''); const [dPhone, setDPhone] = useState('');
  const [dEmail, setDEmail] = useState(''); const [dPhoto, setDPhoto] = useState(''); const [dOrdre, setDOrdre] = useState('1');

  // Arbitres
  const [editA, setEditA] = useState<Arbitre | null>(null);
  const [showAddA, setShowAddA] = useState(false);
  const [aNom, setANom] = useState(''); const [aPrenom, setAPrenom] = useState(''); const [aPhone, setAPhone] = useState('');
  const [aEmail, setAEmail] = useState(''); const [aPhoto, setAPhoto] = useState('');
  const [aNiveau, setANiveau] = useState<Arbitre['niveau']>('Club'); const [aOrdre, setAOrdre] = useState('1');

  // Club info
  const [editField, setEditField] = useState<'adresse' | 'email' | 'telephone' | 'horaires' | null>(null);
  const [fieldValue, setFieldValue] = useState('');
  const [showAddHoraire, setShowAddHoraire] = useState(false);
  const [newHoraire, setNewHoraire] = useState('');

  // Delete
  const [delTarget, setDelTarget] = useState<{ type: 'dirigeant' | 'arbitre'; id: string } | null>(null);

  // Tri
  const sortedDir = [...dirigeants].sort((a, b) => a.ordre - b.ordre);
  const president = sortedDir.find(d => d.ordre === 1);
  const othersDir = sortedDir.filter(d => d.ordre !== 1);

  const sortedArb = [...arbitres].sort((a, b) => a.ordre - b.ordre);
  const arbChef = sortedArb.find(a => a.ordre === 1);
  const othersArb = sortedArb.filter(a => a.ordre !== 1);

  // ===== Dirigeants handlers =====
  function openAddD() { setDRole(''); setDName(''); setDPhone(''); setDEmail(''); setDPhoto(''); setDOrdre((dirigeants.length + 1).toString()); setShowAddD(true); }
  function openEditD(d: Dirigeant) { setDRole(d.role); setDName(d.name); setDPhone(d.phone); setDEmail(d.email); setDPhoto(d.photo); setDOrdre(d.ordre.toString()); setEditD(d); }
  function saveDir(e: React.FormEvent) { e.preventDefault();
    const data = { role: dRole, name: dName, phone: dPhone, email: dEmail, photo: dPhoto, ordre: parseInt(dOrdre) || 1 };
    if (editD) { setDirigeants(dirigeants.map(d => d.id === editD.id ? { ...d, ...data } : d)); setEditD(null); }
    else { setDirigeants([...dirigeants, { id: uid(), ...data }]); setShowAddD(false); }
  }

  // ===== Arbitres handlers =====
  function openAddA() { setANom(''); setAPrenom(''); setAPhone(''); setAEmail(''); setAPhoto(''); setANiveau('Club'); setAOrdre((arbitres.length + 1).toString()); setShowAddA(true); }
  function openEditA(a: Arbitre) { setANom(a.nom); setAPrenom(a.prenom); setAPhone(a.phone); setAEmail(a.email); setAPhoto(a.photo); setANiveau(a.niveau); setAOrdre(a.ordre.toString()); setEditA(a); }
  function saveArbitre(e: React.FormEvent) { e.preventDefault();
    const data = { nom: aNom, prenom: aPrenom, phone: aPhone, email: aEmail, photo: aPhoto, niveau: aNiveau, ordre: parseInt(aOrdre) || 1 };
    if (editA) { setArbitres(arbitres.map(a => a.id === editA.id ? { ...a, ...data } : a)); setEditA(null); }
    else { setArbitres([...arbitres, { id: uid(), ...data }]); setShowAddA(false); }
  }

  // ===== Club info handlers =====
  function openEditField(field: 'adresse' | 'email' | 'telephone' | 'horaires') {
    setFieldValue(field === 'horaires' ? clubInfo.horaires.join('\n') : clubInfo[field]); setEditField(field);
  }
  function saveField(e: React.FormEvent) { e.preventDefault(); if (!editField) return;
    if (editField === 'horaires') setClubInfo({ ...clubInfo, horaires: fieldValue.split('\n').filter(Boolean) });
    else setClubInfo({ ...clubInfo, [editField]: fieldValue }); setEditField(null);
  }
  function removeHoraire(index: number) { setClubInfo({ ...clubInfo, horaires: clubInfo.horaires.filter((_, i) => i !== index) }); }
  function addHoraire(e: React.FormEvent) { e.preventDefault(); if (!newHoraire.trim()) return;
    setClubInfo({ ...clubInfo, horaires: [...clubInfo.horaires, newHoraire.trim()] }); setShowAddHoraire(false); setNewHoraire('');
  }

  function handleDelete() {
    if (!delTarget) return;
    if (delTarget.type === 'dirigeant') setDirigeants(dirigeants.filter(d => d.id !== delTarget.id));
    else setArbitres(arbitres.filter(a => a.id !== delTarget.id));
    setDelTarget(null);
  }

  // ===== Carte générique organigramme =====
  function OrgCard({ name, role, photo, emoji, gradient, phone, email, badge, large, onEdit, onDelete }: {
    name: string; role: string; photo: string; emoji: string; gradient: string;
    phone?: string; email?: string; badge?: React.ReactNode; large?: boolean;
    onEdit: () => void; onDelete: () => void;
  }) {
    return (
      <div className={`bg-white rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-100 overflow-hidden relative group ${large ? 'max-w-sm mx-auto' : ''}`}>
        <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
          <EditButton onClick={onEdit} />
          <DeleteButton onClick={onDelete} />
        </div>
        <div className={`bg-gradient-to-br ${gradient} p-4 text-center`}>
          <div className={`${large ? 'w-24 h-24' : 'w-20 h-20'} rounded-full mx-auto border-3 border-white/30 overflow-hidden bg-white/10 flex items-center justify-center`}>
            {photo ? <img src={photo} alt={name} className="w-full h-full object-cover" /> : <span className={large ? 'text-4xl' : 'text-3xl'}>{emoji}</span>}
          </div>
          <div className="mt-3">
            <span className="bg-white/20 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">{role}</span>
          </div>
        </div>
        <div className="p-4 text-center">
          <h4 className={`font-bold text-[#2c3e50] ${large ? 'text-lg' : 'text-sm'}`}>{name}</h4>
          {badge && <div className="mt-2">{badge}</div>}
          {phone && <div className="flex items-center justify-center gap-1.5 mt-2 text-xs text-gray-500"><Phone size={12} className="text-[#1abc9c]" />{phone}</div>}
          {email && <div className="flex items-center justify-center gap-1.5 mt-1 text-xs text-gray-500"><Mail size={12} className="text-[#1abc9c]" />{email}</div>}
        </div>
      </div>
    );
  }

  // ===== Organigramme générique =====
  function Organigramme({ chef, others }: {
    chef: React.ReactNode | null; others: React.ReactNode[];
  }) {
    return (
      <div className="relative">
        {chef && (
          <div className="mb-6">
            {chef}
            {others.length > 0 && <div className="flex justify-center"><div className="w-0.5 h-8 bg-[#1abc9c]"></div></div>}
          </div>
        )}
        {others.length > 0 && (
          <div className={`grid gap-5 ${
            others.length === 1 ? 'grid-cols-1 max-w-sm mx-auto' :
            others.length === 2 ? 'grid-cols-1 sm:grid-cols-2 max-w-2xl mx-auto' :
            others.length === 3 ? 'grid-cols-1 sm:grid-cols-3 max-w-4xl mx-auto' :
            'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'
          }`}>
            {others.map((card, i) => (
              <div key={i}>
                <div className="hidden md:flex justify-center"><div className="w-0.5 h-4 bg-[#1abc9c]"></div></div>
                {card}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <section id="club" className="py-16 px-4 sm:px-6 bg-[#ecf0f1]">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-extrabold text-[#2c3e50] mb-2 flex items-center gap-3">
          <span className="w-1.5 h-8 bg-[#1abc9c] rounded-full inline-block" /> Notre Club
        </h2>
        <p className="text-gray-500 mb-10">Organigramme du bureau, arbitres et informations</p>

        {/* ===== ORGANIGRAMME BUREAU ===== */}
        <div className="mb-14">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-[#2c3e50] flex items-center gap-2">🏛️ Organigramme du Bureau</h3>
            <AddButton onClick={openAddD} label="Ajouter un membre" />
          </div>
          {dirigeants.length > 0 ? (
            <Organigramme
              chef={president ? <OrgCard name={president.name} role={president.role} photo={president.photo} emoji={getRoleEmoji(president.role)} gradient={getRoleColor(president.role)} phone={president.phone} email={president.email} large onEdit={() => openEditD(president)} onDelete={() => setDelTarget({ type: 'dirigeant', id: president.id })} /> : null}
              others={othersDir.map(d => <OrgCard key={d.id} name={d.name} role={d.role} photo={d.photo} emoji={getRoleEmoji(d.role)} gradient={getRoleColor(d.role)} phone={d.phone} email={d.email} onEdit={() => openEditD(d)} onDelete={() => setDelTarget({ type: 'dirigeant', id: d.id })} />)}
            />
          ) : (
            <div className="text-center py-12 text-gray-400"><User size={40} className="mx-auto mb-2 opacity-30" /><p className="font-medium">Aucun membre dans le bureau</p>
              {isAdmin && <p className="text-xs mt-1">Cliquez sur "Ajouter un membre"</p>}</div>
          )}
        </div>

        {/* ===== ORGANIGRAMME ARBITRES ===== */}
        <div className="mb-14">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-[#2c3e50] flex items-center gap-2">
              <Scale size={20} className="text-[#e74c3c]" /> Organigramme des Arbitres
              <span className="text-sm text-gray-400 font-normal ml-1">({arbitres.length})</span>
            </h3>
            <AddButton onClick={openAddA} label="Ajouter un arbitre" />
          </div>
          {arbitres.length > 0 ? (
            <Organigramme
              chef={arbChef ? <OrgCard name={`${arbChef.prenom} ${arbChef.nom}`} role="Arbitre Principal" photo={arbChef.photo} emoji="⚖️" gradient={getArbitreGradient(arbChef.niveau)} phone={arbChef.phone} email={arbChef.email} large
                badge={<span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${getNiveauColor(arbChef.niveau)}`}>{arbChef.niveau}</span>}
                onEdit={() => openEditA(arbChef)} onDelete={() => setDelTarget({ type: 'arbitre', id: arbChef.id })} /> : null}
              others={othersArb.map(a => <OrgCard key={a.id} name={`${a.prenom} ${a.nom}`} role="Arbitre" photo={a.photo} emoji="⚖️" gradient={getArbitreGradient(a.niveau)} phone={a.phone} email={a.email}
                badge={<span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${getNiveauColor(a.niveau)}`}>{a.niveau}</span>}
                onEdit={() => openEditA(a)} onDelete={() => setDelTarget({ type: 'arbitre', id: a.id })} />)}
            />
          ) : (
            <div className="text-center py-12 text-gray-400 bg-white rounded-xl border border-gray-100"><Scale size={40} className="mx-auto mb-2 opacity-30" /><p className="font-medium">Aucun arbitre enregistré</p>
              {isAdmin && <p className="text-xs mt-1">Cliquez sur "Ajouter un arbitre"</p>}</div>
          )}
        </div>

        {/* ===== INFORMATIONS DU CLUB ===== */}
        <div>
          <h3 className="text-xl font-bold text-[#2c3e50] flex items-center gap-2 mb-5">📍 Informations du Club</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Adresse */}
            <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2"><div className="bg-[#1abc9c]/10 w-10 h-10 rounded-full flex items-center justify-center"><MapPin size={18} className="text-[#1abc9c]" /></div><span className="font-semibold text-[#2c3e50] text-sm">Adresse</span></div>
                {isAdmin && <button onClick={() => openEditField('adresse')} className="text-xs bg-blue-50 hover:bg-blue-100 text-blue-600 px-2 py-1 rounded-lg font-semibold transition-colors">✏️</button>}
              </div>
              <p className="text-gray-600 text-sm whitespace-pre-line leading-relaxed">{clubInfo.adresse || <span className="text-gray-300 italic">Non renseigné</span>}</p>
            </div>
            {/* Email */}
            <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2"><div className="bg-[#1abc9c]/10 w-10 h-10 rounded-full flex items-center justify-center"><Mail size={18} className="text-[#1abc9c]" /></div><span className="font-semibold text-[#2c3e50] text-sm">Email</span></div>
                {isAdmin && <button onClick={() => openEditField('email')} className="text-xs bg-blue-50 hover:bg-blue-100 text-blue-600 px-2 py-1 rounded-lg font-semibold transition-colors">✏️</button>}
              </div>
              <p className="text-gray-600 text-sm break-all">{clubInfo.email || <span className="text-gray-300 italic">Non renseigné</span>}</p>
            </div>
            {/* Téléphone */}
            <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2"><div className="bg-[#1abc9c]/10 w-10 h-10 rounded-full flex items-center justify-center"><Phone size={18} className="text-[#1abc9c]" /></div><span className="font-semibold text-[#2c3e50] text-sm">Téléphone</span></div>
                {isAdmin && <button onClick={() => openEditField('telephone')} className="text-xs bg-blue-50 hover:bg-blue-100 text-blue-600 px-2 py-1 rounded-lg font-semibold transition-colors">✏️</button>}
              </div>
              <p className="text-gray-600 text-sm">{clubInfo.telephone || <span className="text-gray-300 italic">Non renseigné</span>}</p>
            </div>
            {/* Horaires */}
            <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2"><div className="bg-[#1abc9c]/10 w-10 h-10 rounded-full flex items-center justify-center">🕐</div><span className="font-semibold text-[#2c3e50] text-sm">Horaires</span></div>
                {isAdmin && <button onClick={() => openEditField('horaires')} className="text-xs bg-blue-50 hover:bg-blue-100 text-blue-600 px-2 py-1 rounded-lg font-semibold transition-colors">✏️</button>}
              </div>
              {clubInfo.horaires.length > 0 ? (
                <div className="text-gray-600 text-sm space-y-1.5">{clubInfo.horaires.map((h, i) => (
                  <div key={i} className="flex items-center justify-between group/h"><span>{h}</span>
                    {isAdmin && <button onClick={() => removeHoraire(i)} className="text-red-400 hover:text-red-600 opacity-0 group-hover/h:opacity-100 transition-opacity text-xs" title="Supprimer">✕</button>}
                  </div>
                ))}</div>
              ) : <p className="text-gray-300 italic text-sm">Non renseigné</p>}
              {isAdmin && <button onClick={() => { setNewHoraire(''); setShowAddHoraire(true); }} className="mt-3 w-full text-xs bg-green-50 hover:bg-green-100 text-green-600 py-1.5 rounded-lg font-semibold transition-colors">+ Ajouter un horaire</button>}
            </div>
          </div>
        </div>
      </div>

      {/* ===== MODALS ===== */}

      {/* Dirigeant */}
      <EditModal open={showAddD || !!editD} onClose={() => { setShowAddD(false); setEditD(null); }} title={editD ? 'Modifier le membre' : 'Ajouter un membre au bureau'}>
        <form onSubmit={saveDir} className="space-y-4">
          <div className="flex justify-center"><PhotoUploadField photo={dPhoto} onChange={setDPhoto} /></div>
          <Field label="Nom complet" value={dName} onChange={setDName} placeholder="Jean-Pierre Martin" required />
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-semibold text-[#2c3e50] mb-1">Rôle</label>
              <select value={dRole} onChange={e => setDRole(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c]">
                <option value="">-- Choisir --</option><option>Président</option><option>Vice-Président</option><option>Secrétaire</option>
                <option>Secrétaire Adjoint</option><option>Trésorier</option><option>Trésorier Adjoint</option>
                <option>Responsable Sportif</option><option>Responsable Jeunes</option><option>Membre</option>
              </select>
            </div>
            <Field label="Position (ordre)" value={dOrdre} onChange={setDOrdre} type="number" placeholder="1" required />
          </div>
          <Field label="Téléphone" value={dPhone} onChange={setDPhone} placeholder="06 12 34 56 78" />
          <Field label="Email" value={dEmail} onChange={setDEmail} placeholder="email@club.fr" />
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-700">💡 <strong>Ordre 1</strong> = en haut de l'organigramme (Président).</div>
          <SaveButton label={editD ? 'Enregistrer' : 'Ajouter'} />
        </form>
      </EditModal>

      {/* Arbitre */}
      <EditModal open={showAddA || !!editA} onClose={() => { setShowAddA(false); setEditA(null); }} title={editA ? "Modifier l'arbitre" : 'Ajouter un arbitre'}>
        <form onSubmit={saveArbitre} className="space-y-4">
          <div className="flex justify-center"><PhotoUploadField photo={aPhoto} onChange={setAPhoto} /></div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Prénom" value={aPrenom} onChange={setAPrenom} placeholder="Jean" required />
            <Field label="Nom" value={aNom} onChange={setANom} placeholder="DUPONT" required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-semibold text-[#2c3e50] mb-1">Niveau</label>
              <select value={aNiveau} onChange={e => setANiveau(e.target.value as Arbitre['niveau'])} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c]">
                <option value="Club">🏠 Club</option><option value="Départemental">🟢 Départemental</option>
                <option value="Régional">🔵 Régional</option><option value="National">🟡 National</option>
              </select>
            </div>
            <Field label="Position (ordre)" value={aOrdre} onChange={setAOrdre} type="number" placeholder="1" required />
          </div>
          <Field label="Téléphone" value={aPhone} onChange={setAPhone} placeholder="06 12 34 56 78" />
          <Field label="Email" value={aEmail} onChange={setAEmail} placeholder="email@club.fr" />
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-700">💡 <strong>Ordre 1</strong> = Arbitre principal (en haut). Le dégradé change selon le niveau.</div>
          <SaveButton label={editA ? 'Enregistrer' : "Ajouter l'arbitre"} />
        </form>
      </EditModal>

      {/* Info club */}
      <EditModal open={!!editField} onClose={() => setEditField(null)} title={
        editField === 'adresse' ? "Modifier l'adresse" : editField === 'email' ? "Modifier l'email" :
        editField === 'telephone' ? 'Modifier le téléphone' : 'Modifier les horaires'
      }>
        <form onSubmit={saveField} className="space-y-3">
          {editField === 'adresse' && <Field label="Adresse" value={fieldValue} onChange={setFieldValue} type="textarea" required />}
          {editField === 'email' && <Field label="Email" value={fieldValue} onChange={setFieldValue} required />}
          {editField === 'telephone' && <Field label="Téléphone" value={fieldValue} onChange={setFieldValue} required />}
          {editField === 'horaires' && <Field label="Horaires (un par ligne)" value={fieldValue} onChange={setFieldValue} type="textarea" required />}
          <SaveButton />
        </form>
      </EditModal>

      <EditModal open={showAddHoraire} onClose={() => setShowAddHoraire(false)} title="Ajouter un horaire">
        <form onSubmit={addHoraire} className="space-y-3">
          <Field label="Nouvel horaire" value={newHoraire} onChange={setNewHoraire} placeholder="Dimanche : 9h – 12h" required />
          <SaveButton label="Ajouter" />
        </form>
      </EditModal>

      {delTarget && <ConfirmDelete message={delTarget.type === 'dirigeant' ? 'Supprimer ce membre ?' : 'Supprimer cet arbitre ?'} onConfirm={handleDelete} onCancel={() => setDelTarget(null)} />}
    </section>
  );
}
