import { useState } from 'react';
import { CreditCard, Clock, XCircle, UserCheck, UserX, Trash2, AlertTriangle } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { LicenceItem, InscriptionLicence } from '../context/DataContext';
import { AddButton, EditModal, Field, SaveButton, ConfirmDelete } from './AdminActions';
import { useAuth } from '../context/AuthContext';

const uid = () => Date.now().toString() + Math.random().toString(36).slice(2, 6);
const gradients = ['from-green-400 to-green-600', 'from-blue-400 to-blue-600', 'from-[#1abc9c] to-[#16a085]', 'from-purple-400 to-purple-600', 'from-orange-400 to-orange-600'];

export default function Licences() {
  const { licences, setLicences, inscriptions, setInscriptions, getPendingInscriptions } = useData();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  // Licence edit
  const [editL, setEditL] = useState<LicenceItem | null>(null);
  const [showAddL, setShowAddL] = useState(false);
  const [delLId, setDelLId] = useState<string | null>(null);
  const [lTitle, setLTitle] = useState('');
  const [lSub, setLSub] = useState('');
  const [lPrice, setLPrice] = useState('');
  const [lPopular, setLPopular] = useState(false);

  // Inscription form
  const [showInscription, setShowInscription] = useState(false);
  const [inscLicence, setInscLicence] = useState('');
  const [inscNom, setInscNom] = useState('');
  const [inscPrenom, setInscPrenom] = useState('');
  const [inscDateN, setInscDateN] = useState('');
  const [inscAdresse, setInscAdresse] = useState('');
  const [inscEmail, setInscEmail] = useState('');
  const [inscTel, setInscTel] = useState('');
  const [inscSuccess, setInscSuccess] = useState(false);
  const [inscError, setInscError] = useState('');

  // Admin: gestion inscriptions
  const [showAdmin, setShowAdmin] = useState(false);
  const [delInscId, setDelInscId] = useState<string | null>(null);

  const pendingCount = getPendingInscriptions();

  // ===== Licence handlers =====
  function openAddL() { setLTitle(''); setLSub(''); setLPrice(''); setLPopular(false); setShowAddL(true); }
  function openEditL(l: LicenceItem) { setLTitle(l.title); setLSub(l.subtitle); setLPrice(l.price); setLPopular(!!l.popular); setEditL(l); }
  function saveLic(e: React.FormEvent) { e.preventDefault();
    const data = { title: lTitle, subtitle: lSub, price: lPrice, popular: lPopular };
    if (editL) { setLicences(licences.map(l => l.id === editL.id ? { ...l, ...data } : l)); setEditL(null); }
    else { setLicences([...licences, { id: uid(), ...data }]); setShowAddL(false); }
  }

  // ===== Inscription handler =====
  function openInscription(licenceTitle: string) {
    setInscLicence(licenceTitle); setInscNom(''); setInscPrenom(''); setInscDateN(''); setInscAdresse(''); setInscEmail(''); setInscTel('');
    setInscSuccess(false); setInscError(''); setShowInscription(true);
  }

  function handleInscription(e: React.FormEvent) {
    e.preventDefault(); setInscError('');
    if (!inscNom || !inscPrenom || !inscDateN || !inscAdresse || !inscEmail || !inscTel) {
      setInscError('Veuillez remplir tous les champs.'); return;
    }
    const newInsc: InscriptionLicence = {
      id: uid(), licenceTitle: inscLicence,
      nom: inscNom, prenom: inscPrenom, dateNaissance: inscDateN,
      adresse: inscAdresse, email: inscEmail, telephone: inscTel,
      dateInscription: new Date().toLocaleDateString('fr-FR'),
      status: 'pending',
    };
    setInscriptions([newInsc, ...inscriptions]);
    setInscSuccess(true);
  }

  // ===== Admin inscription handlers =====
  function approveInsc(id: string) { setInscriptions(inscriptions.map(i => i.id === id ? { ...i, status: 'approved' as const } : i)); }
  function rejectInsc(id: string) { setInscriptions(inscriptions.map(i => i.id === id ? { ...i, status: 'rejected' as const } : i)); }

  return (
    <section id="licences" className="py-16 px-4 sm:px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-3xl font-extrabold text-[#2c3e50] flex items-center gap-3">
            <span className="w-1.5 h-8 bg-[#1abc9c] rounded-full inline-block" /> Licences
          </h2>
          <div className="flex items-center gap-2">
            {isAdmin && pendingCount > 0 && (
              <button onClick={() => setShowAdmin(!showAdmin)}
                className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-colors animate-pulse">
                <AlertTriangle size={14} /> {pendingCount} inscription{pendingCount > 1 ? 's' : ''} en attente
              </button>
            )}
            {isAdmin && inscriptions.length > 0 && pendingCount === 0 && (
              <button onClick={() => setShowAdmin(!showAdmin)}
                className="flex items-center gap-1.5 bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors">
                📋 Voir les inscriptions ({inscriptions.length})
              </button>
            )}
            <AddButton onClick={openAddL} label="Ajouter une licence" />
          </div>
        </div>
        <p className="text-gray-500 mb-10">Rejoignez-nous ! Choisissez votre formule</p>

        {/* ===== ADMIN: Inscriptions en attente ===== */}
        {isAdmin && showAdmin && (
          <div className="mb-10 bg-gray-50 rounded-xl border border-gray-200 p-5">
            <h3 className="font-bold text-[#2c3e50] mb-4 flex items-center gap-2">
              📋 Demandes d'inscription aux licences
            </h3>
            {inscriptions.length === 0 ? (
              <p className="text-gray-400 text-center py-6">Aucune demande d'inscription</p>
            ) : (
              <div className="space-y-3">
                {inscriptions.map(insc => (
                  <div key={insc.id} className={`bg-white rounded-xl border p-4 ${
                    insc.status === 'pending' ? 'border-amber-200' : insc.status === 'approved' ? 'border-green-200' : 'border-red-200'
                  }`}>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            insc.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                            insc.status === 'approved' ? 'bg-green-100 text-green-700' :
                            'bg-red-100 text-red-700'
                          }`}>
                            {insc.status === 'pending' ? '⏳ En attente' : insc.status === 'approved' ? '✅ Validée' : '❌ Refusée'}
                          </span>
                          <span className="bg-[#1abc9c]/10 text-[#1abc9c] text-[10px] font-bold px-2 py-0.5 rounded-full">
                            {insc.licenceTitle}
                          </span>
                        </div>
                        <h4 className="font-bold text-[#2c3e50] text-sm">{insc.prenom} {insc.nom}</h4>
                        <div className="text-xs text-gray-500 mt-1 space-y-0.5">
                          <p>📅 Né(e) le {insc.dateNaissance}</p>
                          <p>📍 {insc.adresse}</p>
                          <p>📧 {insc.email} · 📞 {insc.telephone}</p>
                          <p className="text-gray-400">Demande du {insc.dateInscription}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {insc.status === 'pending' && (
                          <>
                            <button onClick={() => approveInsc(insc.id)}
                              className="flex items-center gap-1 bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded-lg text-xs font-bold transition-colors">
                              <UserCheck size={14} /> Valider
                            </button>
                            <button onClick={() => rejectInsc(insc.id)}
                              className="flex items-center gap-1 bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded-lg text-xs font-bold transition-colors">
                              <UserX size={14} /> Refuser
                            </button>
                          </>
                        )}
                        {insc.status === 'approved' && (
                          <button onClick={() => rejectInsc(insc.id)}
                            className="flex items-center gap-1 bg-amber-500 hover:bg-amber-600 text-white px-2 py-1.5 rounded-lg text-[10px] font-bold transition-colors">
                            Annuler
                          </button>
                        )}
                        {insc.status === 'rejected' && (
                          <button onClick={() => approveInsc(insc.id)}
                            className="flex items-center gap-1 bg-green-500 hover:bg-green-600 text-white px-2 py-1.5 rounded-lg text-[10px] font-bold transition-colors">
                            Réactiver
                          </button>
                        )}
                        <button onClick={() => setDelInscId(insc.id)}
                          className="text-gray-400 hover:text-red-500 p-1.5 transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ===== CARTES LICENCES ===== */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {licences.map((plan, i) => (
            <div key={plan.id} className={`relative bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border ${plan.popular ? 'border-[#1abc9c] ring-2 ring-[#1abc9c]/20' : 'border-gray-100'}`}>
              {plan.popular && <div className="absolute top-3 left-3 bg-[#1abc9c] text-white text-[10px] font-bold px-2 py-0.5 rounded-full z-10">POPULAIRE</div>}
              <div className={`bg-gradient-to-br ${gradients[i % gradients.length]} px-5 py-8 text-white text-center`}>
                <CreditCard size={32} className="mx-auto mb-3 opacity-80" />
                <h3 className="font-bold text-xl">{plan.title}</h3>
                <p className="text-white/70 text-sm mt-1">{plan.subtitle}</p>
                <div className="text-4xl font-extrabold mt-3">{plan.price}</div>
                <p className="text-white/60 text-xs mt-1">par saison</p>
              </div>
              <div className="p-5 space-y-2">
                <button onClick={() => openInscription(plan.title)}
                  className="w-full bg-[#2c3e50] hover:bg-[#1abc9c] text-white py-3 rounded-lg font-semibold text-sm transition-colors">
                  S'inscrire
                </button>
                {isAdmin && (
                  <div className="flex gap-2">
                    <button onClick={() => openEditL(plan)}
                      className="flex-1 flex items-center justify-center gap-1 bg-blue-50 hover:bg-blue-100 text-blue-600 py-2 rounded-lg text-xs font-semibold transition-colors">
                      ✏️ Modifier
                    </button>
                    <button onClick={() => setDelLId(plan.id)}
                      className="flex-1 flex items-center justify-center gap-1 bg-red-50 hover:bg-red-100 text-red-600 py-2 rounded-lg text-xs font-semibold transition-colors">
                      🗑️ Supprimer
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        {licences.length === 0 && <p className="text-gray-400 text-center py-12">Aucune licence</p>}
      </div>

      {/* ===== MODAL: Inscription licence ===== */}
      <EditModal open={showInscription} onClose={() => { setShowInscription(false); setInscSuccess(false); setInscError(''); }} title={inscSuccess ? 'Demande envoyée !' : `Inscription – Licence ${inscLicence}`}>
        {inscSuccess ? (
          <div className="text-center py-6">
            <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock size={32} className="text-amber-600" />
            </div>
            <h3 className="text-xl font-bold text-[#2c3e50] mb-2">Demande envoyée !</h3>
            <p className="text-gray-600 text-sm leading-relaxed mb-2">
              Votre demande d'inscription à la licence <strong className="text-[#1abc9c]">{inscLicence}</strong> a bien été enregistrée.
            </p>
            <p className="text-amber-600 text-sm font-semibold mb-4">
              ⏳ L'administrateur doit valider votre inscription.
            </p>
            <button onClick={() => { setShowInscription(false); setInscSuccess(false); }}
              className="bg-[#2c3e50] hover:bg-[#34495e] text-white px-6 py-2.5 rounded-lg font-semibold text-sm transition-colors">
              Fermer
            </button>
          </div>
        ) : (
          <form onSubmit={handleInscription} className="space-y-3">
            <div className="bg-[#1abc9c]/10 border border-[#1abc9c]/20 rounded-lg p-3 text-xs text-[#2c3e50]">
              📝 Licence sélectionnée : <strong>{inscLicence}</strong>
            </div>

            {inscError && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-2 rounded-lg text-sm flex items-center gap-2">
                <XCircle size={14} /> {inscError}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <Field label="Prénom" value={inscPrenom} onChange={setInscPrenom} placeholder="Jean" required />
              <Field label="Nom" value={inscNom} onChange={setInscNom} placeholder="DUPONT" required />
            </div>
            <Field label="Date de naissance" value={inscDateN} onChange={setInscDateN} placeholder="15/03/1985" required />
            <Field label="Adresse complète" value={inscAdresse} onChange={setInscAdresse} type="textarea" placeholder="12 rue de la Paix&#10;86530 Naintré" required />
            <Field label="Email" value={inscEmail} onChange={setInscEmail} placeholder="jean.dupont@email.fr" required />
            <Field label="Téléphone" value={inscTel} onChange={setInscTel} placeholder="06 12 34 56 78" required />

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-700">
              ⏳ <strong>Votre inscription sera soumise à validation</strong> par l'administrateur du club.
            </div>

            <SaveButton label="Envoyer ma demande d'inscription" />
          </form>
        )}
      </EditModal>

      {/* ===== MODAL: Edit licence ===== */}
      <EditModal open={showAddL || !!editL} onClose={() => { setShowAddL(false); setEditL(null); }} title={editL ? 'Modifier la licence' : 'Nouvelle licence'}>
        <form onSubmit={saveLic} className="space-y-3">
          <Field label="Titre" value={lTitle} onChange={setLTitle} placeholder="Adultes" required />
          <Field label="Sous-titre" value={lSub} onChange={setLSub} placeholder="18 ans et plus" required />
          <Field label="Prix" value={lPrice} onChange={setLPrice} placeholder="40€" required />
          <div className="flex items-center gap-2">
            <input type="checkbox" checked={lPopular} onChange={e => setLPopular(e.target.checked)} id="popular" className="w-4 h-4 accent-[#1abc9c]" />
            <label htmlFor="popular" className="text-sm text-[#2c3e50] font-medium">Marquer comme "Populaire"</label>
          </div>
          <SaveButton />
        </form>
      </EditModal>

      {delLId && <ConfirmDelete message="Supprimer cette licence ?" onConfirm={() => { setLicences(licences.filter(l => l.id !== delLId)); setDelLId(null); }} onCancel={() => setDelLId(null)} />}
      {delInscId && <ConfirmDelete message="Supprimer cette inscription ?" onConfirm={() => { setInscriptions(inscriptions.filter(i => i.id !== delInscId)); setDelInscId(null); }} onCancel={() => setDelInscId(null)} />}
    </section>
  );
}
