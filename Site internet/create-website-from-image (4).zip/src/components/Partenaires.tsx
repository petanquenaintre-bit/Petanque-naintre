import { useState } from 'react';
import { Heart } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { PartenaireItem } from '../context/DataContext';
import { AddButton, EditButton, DeleteButton, EditModal, Field, SaveButton, ConfirmDelete } from './AdminActions';

const uid = () => Date.now().toString() + Math.random().toString(36).slice(2, 6);

export default function Partenaires() {
  const { partenaires, setPartenaires } = useData();
  const [editP, setEditP] = useState<PartenaireItem | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [delId, setDelId] = useState<string | null>(null);

  const [pName, setPName] = useState(''); const [pType, setPType] = useState(''); const [pDesc, setPDesc] = useState('');

  function openAdd() { setPName(''); setPType(''); setPDesc(''); setShowAdd(true); }
  function openEdit(p: PartenaireItem) { setPName(p.name); setPType(p.type); setPDesc(p.description); setEditP(p); }
  function savePart(e: React.FormEvent) { e.preventDefault();
    const data = { name: pName, type: pType, description: pDesc };
    if (editP) { setPartenaires(partenaires.map(p => p.id === editP.id ? { ...p, ...data } : p)); setEditP(null); }
    else { setPartenaires([...partenaires, { id: uid(), ...data }]); setShowAdd(false); }
  }

  return (
    <section id="partenaires" className="py-16 px-4 sm:px-6 bg-[#ecf0f1]">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-3xl font-extrabold text-[#2c3e50] flex items-center gap-3">
            <span className="w-1.5 h-8 bg-[#1abc9c] rounded-full inline-block" /> Partenaires
          </h2>
          <AddButton onClick={openAdd} label="Ajouter un partenaire" />
        </div>
        <p className="text-gray-500 mb-10">Merci à nos sponsors et partenaires</p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {partenaires.map((p) => (
            <div key={p.id} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 group relative">
              <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <EditButton onClick={() => openEdit(p)} />
                <DeleteButton onClick={() => setDelId(p.id)} />
              </div>
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-[#1abc9c]/10 w-12 h-12 rounded-full flex items-center justify-center"><Heart size={20} className="text-[#1abc9c]" /></div>
                <div><h3 className="font-bold text-[#2c3e50]">{p.name}</h3><span className="text-xs text-[#1abc9c] font-semibold">{p.type}</span></div>
              </div>
              <p className="text-gray-600 text-sm">{p.description}</p>
            </div>
          ))}
        </div>
        {partenaires.length === 0 && <p className="text-gray-400 text-center py-12">Aucun partenaire</p>}
      </div>

      <EditModal open={showAdd || !!editP} onClose={() => { setShowAdd(false); setEditP(null); }} title={editP ? 'Modifier le partenaire' : 'Nouveau partenaire'}>
        <form onSubmit={savePart} className="space-y-3">
          <Field label="Nom" value={pName} onChange={setPName} placeholder="Mairie de Naintré" required />
          <Field label="Type" value={pType} onChange={setPType} placeholder="Sponsor principal" required />
          <Field label="Description" value={pDesc} onChange={setPDesc} type="textarea" placeholder="Description..." required />
          <SaveButton />
        </form>
      </EditModal>

      {delId && <ConfirmDelete message="Supprimer ce partenaire ?" onConfirm={() => { setPartenaires(partenaires.filter(p => p.id !== delId)); setDelId(null); }} onCancel={() => setDelId(null)} />}
    </section>
  );
}
