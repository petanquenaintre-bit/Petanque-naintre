import { useState } from 'react';
import { Trophy, Settings, Plus, Trash2, Pencil, Home } from 'lucide-react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import type { Competition, ClubClassement } from '../context/DataContext';
import { EditModal, Field, SaveButton, ConfirmDelete } from './AdminActions';

const uid = () => Date.now().toString() + Math.random().toString(36).slice(2, 6);

export default function Scores() {
  const { competitions, setCompetitions } = useData();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const [activeTab, setActiveTab] = useState(0);
  // Add competition
  const [showAddComp, setShowAddComp] = useState(false);
  const [compName, setCompName] = useState('');
  // Edit competition name
  const [showEditComp, setShowEditComp] = useState(false);
  // Add club
  const [showAddClub, setShowAddClub] = useState(false);
  const [clubName, setClubName] = useState('');
  const [clubIsHome, setClubIsHome] = useState(false);
  // Edit club
  const [editClubId, setEditClubId] = useState<string | null>(null);
  // Delete
  const [delTarget, setDelTarget] = useState<{ type: 'comp' | 'club'; id: string } | null>(null);

  const comp = competitions[activeTab] || null;

  // ===== Calcul classement auto =====
  function calcPts(c: ClubClassement, bareme: Competition['bareme']) {
    return c.v * bareme.victoire + c.n * bareme.nul + c.d * bareme.defaite + c.forf * bareme.forfait;
  }

  function getSorted(comp: Competition): (ClubClassement & { pts: number; diff: number })[] {
    return comp.clubs
      .map(c => ({ ...c, pts: calcPts(c, comp.bareme), diff: c.bp - c.bc }))
      .sort((a, b) => b.pts - a.pts || b.diff - a.diff || b.bp - a.bp);
  }

  // ===== Barème =====
  function updateBareme(field: keyof Competition['bareme'], val: string) {
    if (!comp) return;
    const updated = competitions.map(c =>
      c.id === comp.id ? { ...c, bareme: { ...c.bareme, [field]: parseInt(val) || 0 } } : c
    );
    setCompetitions(updated);
  }

  // ===== Club stats update =====
  function updateClubStat(clubId: string, field: keyof ClubClassement, val: string) {
    if (!comp) return;
    const numVal = parseInt(val) || 0;
    const updated = competitions.map(c => {
      if (c.id !== comp.id) return c;
      return {
        ...c,
        clubs: c.clubs.map(cl => {
          if (cl.id !== clubId) return cl;
          const newCl = { ...cl, [field]: numVal };
          // Auto-calc J = V + N + D + Forf
          if (['v', 'n', 'd', 'forf'].includes(field)) {
            newCl.j = newCl.v + newCl.n + newCl.d + newCl.forf;
          }
          return newCl;
        }),
      };
    });
    setCompetitions(updated);
  }

  // ===== Add competition =====
  function handleAddComp(e: React.FormEvent) {
    e.preventDefault();
    const newComp: Competition = {
      id: uid(), nom: compName,
      bareme: { victoire: 3, nul: 2, defaite: 1, forfait: 0 },
      clubs: [],
    };
    setCompetitions([...competitions, newComp]);
    setActiveTab(competitions.length);
    setShowAddComp(false); setCompName('');
  }

  // ===== Edit competition name =====
  function handleEditComp(e: React.FormEvent) {
    e.preventDefault();
    if (!comp) return;
    setCompetitions(competitions.map(c => c.id === comp.id ? { ...c, nom: compName } : c));
    setShowEditComp(false);
  }

  // ===== Add club =====
  function handleAddClub(e: React.FormEvent) {
    e.preventDefault();
    if (!comp) return;
    const newClub: ClubClassement = {
      id: uid(), nom: clubName, isHome: clubIsHome,
      j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0,
    };
    setCompetitions(competitions.map(c =>
      c.id === comp.id ? { ...c, clubs: [...c.clubs, newClub] } : c
    ));
    setShowAddClub(false); setClubName(''); setClubIsHome(false);
  }

  // ===== Edit club =====
  function openEditClub(cl: ClubClassement) {
    setClubName(cl.nom); setClubIsHome(cl.isHome); setEditClubId(cl.id);
  }
  function handleEditClub(e: React.FormEvent) {
    e.preventDefault();
    if (!comp || !editClubId) return;
    setCompetitions(competitions.map(c =>
      c.id === comp.id ? { ...c, clubs: c.clubs.map(cl => cl.id === editClubId ? { ...cl, nom: clubName, isHome: clubIsHome } : cl) } : c
    ));
    setEditClubId(null); setClubName(''); setClubIsHome(false);
  }

  // ===== Delete =====
  function handleDelete() {
    if (!delTarget) return;
    if (delTarget.type === 'comp') {
      const newComps = competitions.filter(c => c.id !== delTarget.id);
      setCompetitions(newComps);
      setActiveTab(Math.max(0, activeTab - 1));
    } else if (comp) {
      setCompetitions(competitions.map(c =>
        c.id === comp.id ? { ...c, clubs: c.clubs.filter(cl => cl.id !== delTarget.id) } : c
      ));
    }
    setDelTarget(null);
  }

  // Stats du club PN dans la compétition active
  const homeClub = comp?.clubs.find(c => c.isHome);
  const sorted = comp ? getSorted(comp) : [];
  const totalMatchs = comp ? comp.clubs.reduce((s, c) => s + c.j, 0) / 2 : 0;
  const homePts = homeClub && comp ? calcPts(homeClub, comp.bareme) : 0;

  return (
    <section id="scores" className="py-16 px-4 sm:px-6 bg-[#ecf0f1]">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-extrabold text-[#2c3e50] mb-8 flex items-center gap-3">
          <Trophy size={28} className="text-[#f39c12]" /> Scores & Classements
        </h2>

        {/* ===== BARÈME ===== */}
        {isAdmin && comp && (
          <div className="bg-white rounded-xl border border-gray-200 p-5 mb-8">
            <h3 className="font-bold text-[#2c3e50] mb-1 flex items-center gap-2 text-sm">
              <Settings size={16} className="text-gray-400" /> Barème des points
              <span className="text-gray-400 font-normal text-xs">(modifiez les valeurs directement)</span>
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
              {[
                { label: '🏆 Victoire', field: 'victoire' as const, color: 'border-green-400' },
                { label: '🤝 Match nul', field: 'nul' as const, color: 'border-yellow-400' },
                { label: '❌ Défaite', field: 'defaite' as const, color: 'border-red-400' },
                { label: '🚫 Forfait', field: 'forfait' as const, color: 'border-gray-400' },
              ].map(b => (
                <div key={b.field} className="text-center">
                  <div className="text-xs text-gray-500 mb-1 font-semibold">{b.label}</div>
                  <input
                    type="number" value={comp.bareme[b.field]}
                    onChange={e => updateBareme(b.field, e.target.value)}
                    className={`w-full text-center text-3xl font-extrabold text-[#2c3e50] border-2 ${b.color} rounded-xl py-3 focus:outline-none focus:ring-2 focus:ring-[#1abc9c]`}
                  />
                </div>
              ))}
            </div>
            <p className="text-xs text-gray-400 mt-3 flex items-center gap-1">💡 Le classement se recalcule dès que vous changez un chiffre.</p>
          </div>
        )}

        {/* ===== ONGLETS COMPÉTITIONS ===== */}
        <div className="flex flex-wrap gap-2 mb-8">
          {competitions.map((c, i) => (
            <button
              key={c.id}
              onClick={() => setActiveTab(i)}
              className={`px-4 py-2 rounded-full text-sm font-bold transition-colors ${
                activeTab === i
                  ? 'bg-[#1abc9c] text-white shadow-md'
                  : 'bg-white text-[#2c3e50] border border-gray-200 hover:bg-gray-50'
              }`}
            >
              {c.nom}
            </button>
          ))}
          {isAdmin && (
            <button
              onClick={() => { setCompName(''); setShowAddComp(true); }}
              className="px-4 py-2 rounded-full text-sm font-bold bg-[#1abc9c] text-white hover:bg-[#16a085] transition-colors flex items-center gap-1"
            >
              <Plus size={14} /> Nouvelle compétition
            </button>
          )}
        </div>

        {comp && (
          <>
            {/* ===== ADMIN: Nom compétition ===== */}
            {isAdmin && (
              <div className="flex items-center gap-2 mb-4">
                <button onClick={() => { setCompName(comp.nom); setShowEditComp(true); }} className="text-gray-400 hover:text-[#3498db] transition-colors" title="Renommer"><Pencil size={14} /></button>
                <button onClick={() => setDelTarget({ type: 'comp', id: comp.id })} className="text-gray-400 hover:text-[#e74c3c] transition-colors" title="Supprimer"><Trash2 size={14} /></button>
                <span className="text-xs text-gray-400">Gérer la compétition</span>
              </div>
            )}

            {/* ===== STATS RÉSUMÉ ===== */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-white rounded-xl p-5 text-center shadow-sm border border-gray-100">
                <div className="text-3xl font-extrabold text-[#1abc9c]">{comp.clubs.length}</div>
                <div className="text-xs text-gray-500 mt-1">Clubs</div>
              </div>
              <div className="bg-white rounded-xl p-5 text-center shadow-sm border border-gray-100">
                <div className="text-3xl font-extrabold text-[#2c3e50]">{Math.floor(totalMatchs)}</div>
                <div className="text-xs text-gray-500 mt-1">Matchs joués</div>
              </div>
              <div className="bg-white rounded-xl p-5 text-center shadow-sm border border-gray-100">
                <div className="text-3xl font-extrabold text-green-500">{homeClub?.v || 0}</div>
                <div className="text-xs text-gray-500 mt-1">Victoires PN</div>
              </div>
              <div className="bg-white rounded-xl p-5 text-center shadow-sm border border-gray-100">
                <div className="text-3xl font-extrabold text-[#f39c12]">{homePts}</div>
                <div className="text-xs text-gray-500 mt-1">Points PN</div>
              </div>
            </div>

            {/* ===== CLASSEMENT ===== */}
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-[#2c3e50] flex items-center gap-2">
                📊 Classement
                <span className="text-xs text-gray-400 font-normal">
                  V={comp.bareme.victoire}pts · N={comp.bareme.nul}pts · D={comp.bareme.defaite}pts · Forfait={comp.bareme.forfait}pts
                </span>
              </h3>
              {isAdmin && (
                <button
                  onClick={() => { setClubName(''); setClubIsHome(false); setShowAddClub(true); }}
                  className="flex items-center gap-1.5 bg-[#1abc9c] hover:bg-[#16a085] text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-colors"
                >
                  <Plus size={14} /> Ajouter un club
                </button>
              )}
            </div>

            <div className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-100">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-[#2c3e50] text-white">
                      <th className="px-3 py-3 text-left font-semibold w-10">Pos.</th>
                      <th className="px-3 py-3 text-left font-semibold">Club</th>
                      <th className="px-3 py-3 text-center font-semibold w-12">J</th>
                      <th className="px-3 py-3 text-center font-semibold w-12 text-green-300">V</th>
                      <th className="px-3 py-3 text-center font-semibold w-12 text-yellow-300">N</th>
                      <th className="px-3 py-3 text-center font-semibold w-12 text-red-300">D</th>
                      <th className="px-3 py-3 text-center font-semibold w-12">Forf</th>
                      <th className="px-3 py-3 text-center font-semibold w-12 text-blue-300">BP</th>
                      <th className="px-3 py-3 text-center font-semibold w-12 text-orange-300">BC</th>
                      <th className="px-3 py-3 text-center font-semibold w-12">Diff</th>
                      <th className="px-3 py-3 text-center font-semibold w-14 text-[#f39c12]">Pts</th>
                      {isAdmin && <th className="px-3 py-3 text-center font-semibold w-16">Actions</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {sorted.map((cl, i) => {
                      const pos = i + 1;
                      const medalEmoji = pos === 1 ? '🥇' : pos === 2 ? '🥈' : pos === 3 ? '🥉' : '';
                      return (
                        <tr
                          key={cl.id}
                          className={`border-b border-gray-50 transition-colors ${
                            cl.isHome ? 'bg-[#1abc9c]/5 font-semibold' : 'hover:bg-gray-50'
                          }`}
                        >
                          <td className="px-3 py-3 text-center">
                            {medalEmoji || <span className="text-gray-400">{pos}</span>}
                          </td>
                          <td className="px-3 py-3 text-[#2c3e50]">
                            <span className="flex items-center gap-1.5">
                              {cl.isHome && <Home size={14} className="text-[#1abc9c]" />}
                              {cl.nom}
                            </span>
                          </td>
                          {/* Stats éditables par admin */}
                          {isAdmin ? (
                            <>
                              <td className="px-1 py-1 text-center">
                                <span className="text-gray-400 text-xs">{cl.j}</span>
                              </td>
                              {(['v', 'n', 'd', 'forf', 'bp', 'bc'] as const).map(field => (
                                <td key={field} className="px-1 py-1 text-center">
                                  <input
                                    type="number" min="0"
                                    value={cl[field]}
                                    onChange={e => updateClubStat(cl.id, field, e.target.value)}
                                    className={`w-12 text-center py-1 border rounded text-sm font-bold focus:outline-none focus:ring-1 focus:ring-[#1abc9c] ${
                                      field === 'v' ? 'text-green-600 border-green-200' :
                                      field === 'n' ? 'text-yellow-600 border-yellow-200' :
                                      field === 'd' ? 'text-red-500 border-red-200' :
                                      field === 'bp' ? 'text-blue-600 border-blue-200' :
                                      field === 'bc' ? 'text-orange-600 border-orange-200' :
                                      'text-gray-600 border-gray-200'
                                    }`}
                                  />
                                </td>
                              ))}
                            </>
                          ) : (
                            <>
                              <td className="px-3 py-3 text-center">{cl.j}</td>
                              <td className="px-3 py-3 text-center text-green-600 font-bold">{cl.v}</td>
                              <td className="px-3 py-3 text-center text-yellow-600">{cl.n}</td>
                              <td className="px-3 py-3 text-center text-red-500">{cl.d}</td>
                              <td className="px-3 py-3 text-center">{cl.forf}</td>
                              <td className="px-3 py-3 text-center text-blue-600">{cl.bp}</td>
                              <td className="px-3 py-3 text-center text-orange-600">{cl.bc}</td>
                            </>
                          )}
                          <td className="px-3 py-3 text-center font-semibold">
                            <span className={cl.diff > 0 ? 'text-green-600' : cl.diff < 0 ? 'text-red-500' : 'text-gray-400'}>
                              {cl.diff > 0 ? '+' : ''}{cl.diff}
                            </span>
                          </td>
                          <td className="px-3 py-3 text-center">
                            <span className="bg-[#f39c12]/15 text-[#f39c12] px-2 py-1 rounded-full text-sm font-extrabold">{cl.pts}</span>
                          </td>
                          {isAdmin && (
                            <td className="px-3 py-3 text-center">
                              <div className="flex items-center justify-center gap-1">
                                <button onClick={() => openEditClub(cl)} className="text-gray-400 hover:text-[#3498db] p-1" title="Modifier"><Pencil size={12} /></button>
                                <button onClick={() => setDelTarget({ type: 'club', id: cl.id })} className="text-gray-400 hover:text-[#e74c3c] p-1" title="Supprimer"><Trash2 size={12} /></button>
                              </div>
                            </td>
                          )}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {comp.clubs.length === 0 && (
                <p className="text-gray-400 text-center py-8">Aucun club dans cette compétition. Ajoutez-en !</p>
              )}
            </div>
          </>
        )}

        {competitions.length === 0 && (
          <div className="text-center py-16 text-gray-400">
            <Trophy size={48} className="mx-auto mb-3 opacity-30" />
            <p className="font-medium">Aucune compétition</p>
            <p className="text-xs mt-1">Créez votre première compétition avec le bouton ci-dessus.</p>
          </div>
        )}
      </div>

      {/* ===== MODALS ===== */}
      <EditModal open={showAddComp} onClose={() => setShowAddComp(false)} title="Nouvelle compétition">
        <form onSubmit={handleAddComp} className="space-y-3">
          <Field label="Nom de la compétition" value={compName} onChange={setCompName} placeholder="Division 1 – CDC Masculin" required />
          <SaveButton label="Créer la compétition" />
        </form>
      </EditModal>

      <EditModal open={showEditComp} onClose={() => setShowEditComp(false)} title="Renommer la compétition">
        <form onSubmit={handleEditComp} className="space-y-3">
          <Field label="Nom" value={compName} onChange={setCompName} required />
          <SaveButton />
        </form>
      </EditModal>

      <EditModal open={showAddClub} onClose={() => setShowAddClub(false)} title="Ajouter un club">
        <form onSubmit={handleAddClub} className="space-y-3">
          <Field label="Nom du club" value={clubName} onChange={setClubName} placeholder="Club de Poitiers" required />
          <div className="flex items-center gap-2">
            <input type="checkbox" checked={clubIsHome} onChange={e => setClubIsHome(e.target.checked)} id="isHome" className="w-4 h-4 accent-[#1abc9c]" />
            <label htmlFor="isHome" className="text-sm text-[#2c3e50] font-medium">🏠 C'est notre club (Pétanque Naintréenne)</label>
          </div>
          <SaveButton label="Ajouter le club" />
        </form>
      </EditModal>

      <EditModal open={!!editClubId} onClose={() => setEditClubId(null)} title="Modifier le club">
        <form onSubmit={handleEditClub} className="space-y-3">
          <Field label="Nom du club" value={clubName} onChange={setClubName} required />
          <div className="flex items-center gap-2">
            <input type="checkbox" checked={clubIsHome} onChange={e => setClubIsHome(e.target.checked)} id="isHomeEdit" className="w-4 h-4 accent-[#1abc9c]" />
            <label htmlFor="isHomeEdit" className="text-sm text-[#2c3e50] font-medium">🏠 C'est notre club</label>
          </div>
          <SaveButton />
        </form>
      </EditModal>

      {delTarget && (
        <ConfirmDelete
          message={delTarget.type === 'comp' ? 'Supprimer cette compétition et tous ses clubs ?' : 'Supprimer ce club du classement ?'}
          onConfirm={handleDelete}
          onCancel={() => setDelTarget(null)}
        />
      )}
    </section>
  );
}
