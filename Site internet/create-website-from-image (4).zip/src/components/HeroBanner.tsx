export default function HeroBanner() {
  return (
    <section id="accueil" className="relative w-full overflow-hidden">
      <div className="relative w-full h-[300px] sm:h-[400px] md:h-[450px] lg:h-[500px]">
        <img
          src="/images/hero-banner.jpg"
          alt="Pétanque Naintréenne Banner"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#2c3e50]/80 via-transparent to-transparent" />

        <div className="absolute bottom-6 left-6 sm:bottom-10 sm:left-10">
          <h1 className="text-white text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-wide drop-shadow-lg">
            PÉTANQUE NAINTRÉENNE
          </h1>
          <p className="text-[#1abc9c] text-sm sm:text-base font-semibold mt-1 drop-shadow">
            NAINTRÉ · VIENNE · 86
          </p>
        </div>

        <div className="absolute bottom-6 right-6 sm:bottom-10 sm:right-10">
          <img
            src="/images/logo.png"
            alt="Logo"
            className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 rounded-full border-3 border-white shadow-xl object-cover"
          />
        </div>
      </div>
    </section>
  );
}
