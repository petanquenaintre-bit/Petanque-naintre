import { useState } from 'react';
import { MessageSquare, User, Clock, ThumbsUp } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { ForumTopic } from '../context/DataContext';
import { AddButton, EditButton, DeleteButton, EditModal, Field, SaveButton, ConfirmDelete } from './AdminActions';

const uid = () => Date.now().toString() + Math.random().toString(36).slice(2, 6);

function getCategoryColor(category: string) {
  const colors: Record<string, string> = { Organisation: 'bg-blue-100 text-blue-700', Compétition: 'bg-red-100 text-red-700', Matériel: 'bg-purple-100 text-purple-700', Logistique: 'bg-orange-100 text-orange-700', 'Vie du club': 'bg-green-100 text-green-700' };
  return colors[category] || 'bg-gray-100 text-gray-700';
}

export default function Forum() {
  const { forum, setForum } = useData();
  const [editF, setEditF] = useState<ForumTopic | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [delId, setDelId] = useState<string | null>(null);

  const [fTitle, setFTitle] = useState(''); const [fAuthor, setFAuthor] = useState(''); const [fCat, setFCat] = useState('');

  function openAdd() { setFTitle(''); setFAuthor(''); setFCat('Organisation'); setShowAdd(true); }
  function openEdit(f: ForumTopic) { setFTitle(f.title); setFAuthor(f.author); setFCat(f.category); setEditF(f); }
  function saveTopic(e: React.FormEvent) { e.preventDefault();
    if (editF) { setForum(forum.map(f => f.id === editF.id ? { ...f, title: fTitle, author: fAuthor, category: fCat } : f)); setEditF(null); }
    else { setForum([{ id: uid(), title: fTitle, author: fAuthor, date: "À l'instant", replies: 0, likes: 0, category: fCat }, ...forum]); setShowAdd(false); }
  }

  return (
    <section id="forum" className="py-16 px-4 sm:px-6 bg-[#ecf0f1]">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-3xl font-extrabold text-[#2c3e50] flex items-center gap-3">
            <span className="w-1.5 h-8 bg-[#1abc9c] rounded-full inline-block" /> Forum
          </h2>
          <AddButton onClick={openAdd} label="Nouveau sujet" />
        </div>
        <p className="text-gray-500 mb-10">Échangez avec les membres du club</p>

        <div className="space-y-3">
          {forum.map((topic) => (
            <div key={topic.id} className="bg-white rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow border border-gray-100 relative group">
              <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <EditButton onClick={() => openEdit(topic)} />
                <DeleteButton onClick={() => setDelId(topic.id)} />
              </div>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${getCategoryColor(topic.category)}`}>{topic.category}</span>
                  <h3 className="font-bold text-[#2c3e50] text-sm mt-2">{topic.title}</h3>
                  <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
                    <span className="flex items-center gap-1"><User size={11} />{topic.author}</span>
                    <span className="flex items-center gap-1"><Clock size={11} />{topic.date}</span>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-xs text-gray-400 shrink-0">
                  <span className="flex items-center gap-1"><MessageSquare size={13} />{topic.replies}</span>
                  <span className="flex items-center gap-1"><ThumbsUp size={13} />{topic.likes}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        {forum.length === 0 && <p className="text-gray-400 text-center py-12">Aucun sujet</p>}
      </div>

      <EditModal open={showAdd || !!editF} onClose={() => { setShowAdd(false); setEditF(null); }} title={editF ? 'Modifier le sujet' : 'Nouveau sujet'}>
        <form onSubmit={saveTopic} className="space-y-3">
          <Field label="Titre" value={fTitle} onChange={setFTitle} placeholder="Titre du sujet" required />
          <Field label="Auteur" value={fAuthor} onChange={setFAuthor} placeholder="Jean-Pierre M." required />
          <div>
            <label className="block text-sm font-semibold text-[#2c3e50] mb-1">Catégorie</label>
            <select value={fCat} onChange={(e) => setFCat(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1abc9c]">
              <option>Organisation</option><option>Compétition</option><option>Matériel</option><option>Logistique</option><option>Vie du club</option>
            </select>
          </div>
          <SaveButton />
        </form>
      </EditModal>

      {delId && <ConfirmDelete message="Supprimer ce sujet ?" onConfirm={() => { setForum(forum.filter(f => f.id !== delId)); setDelId(null); }} onCancel={() => setDelId(null)} />}
    </section>
  );
}
