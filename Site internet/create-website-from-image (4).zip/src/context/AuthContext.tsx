import { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';

export interface User {
  id: string;
  pseudo: string;
  email: string;
  nom: string;
  prenom: string;
  role: 'admin' | 'membre';
  status: 'approved' | 'pending' | 'rejected';
  dateInscription: string;
  avatar: string;
}

interface StoredUser extends User {
  password: string;
}

interface AuthContextType {
  user: User | null;
  login: (pseudo: string, password: string) => { success: boolean; error?: string };
  register: (data: RegisterData) => { success: boolean; error?: string };
  logout: () => void;
  showAuthModal: boolean;
  setShowAuthModal: (show: boolean) => void;
  authTab: 'login' | 'register';
  setAuthTab: (tab: 'login' | 'register') => void;
  // User functions
  changePassword: (currentPassword: string, newPassword: string) => { success: boolean; error?: string };
  // Admin functions
  getAllUsers: () => StoredUser[];
  approveUser: (id: string) => void;
  rejectUser: (id: string) => void;
  deleteUser: (id: string) => void;
  getPendingCount: () => number;
  // Compteur connexions
  getConnexionStats: () => { total: number; parAnnee: Record<string, number>; logs: ConnexionLog[] };
}

export interface ConnexionLog {
  pseudo: string;
  date: string;
  heure: string;
  annee: string;
}

interface RegisterData {
  pseudo: string;
  email: string;
  password: string;
  nom: string;
  prenom: string;
}

const AuthContext = createContext<AuthContextType | null>(null);

const avatars = ['🎯', '🏆', '⚽', '🎳', '🌟', '🔥', '💪', '🎪'];

function getRandomAvatar() {
  return avatars[Math.floor(Math.random() * avatars.length)];
}

// ========== COMPTE ADMIN PAR DÉFAUT ==========
const ADMIN_ACCOUNT: StoredUser = {
  id: 'admin-001',
  pseudo: 'Mickey',
  email: 'mickey@petanque-naintreenne.fr',
  nom: 'Mickey',
  prenom: 'Mickey',
  password: 'Alexy203',
  role: 'admin',
  status: 'approved',
  dateInscription: new Date().toLocaleDateString('fr-FR'),
  avatar: '👑',
};

// Version du schéma admin — changer ce numéro force un reset du compte admin
const ADMIN_VERSION = 'v4';

function initUsers(): StoredUser[] {
  // Forcer le reset si la version admin a changé
  const storedVersion = localStorage.getItem('pn_admin_version');
  if (storedVersion !== ADMIN_VERSION) {
    localStorage.removeItem('pn_users');
    localStorage.removeItem('pn_session');
    localStorage.setItem('pn_admin_version', ADMIN_VERSION);
  }

  const data = localStorage.getItem('pn_users');
  if (!data) {
    const users = [ADMIN_ACCOUNT];
    localStorage.setItem('pn_users', JSON.stringify(users));
    return users;
  }
  const users: StoredUser[] = JSON.parse(data);
  // S'assurer que l'admin existe toujours et est à jour
  const adminIdx = users.findIndex((u) => u.id === 'admin-001');
  if (adminIdx === -1) {
    users.unshift(ADMIN_ACCOUNT);
  } else {
    users[adminIdx] = { ...ADMIN_ACCOUNT, dateInscription: users[adminIdx].dateInscription };
  }
  localStorage.setItem('pn_users', JSON.stringify(users));
  return users;
}

function getStoredUsers(): StoredUser[] {
  try {
    return initUsers();
  } catch {
    const users = [ADMIN_ACCOUNT];
    localStorage.setItem('pn_users', JSON.stringify(users));
    return users;
  }
}

function saveStoredUsers(users: StoredUser[]) {
  localStorage.setItem('pn_users', JSON.stringify(users));
}

function getSessionUser(): User | null {
  try {
    const data = localStorage.getItem('pn_session');
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

function saveSession(user: User | null) {
  if (user) {
    localStorage.setItem('pn_session', JSON.stringify(user));
  } else {
    localStorage.removeItem('pn_session');
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authTab, setAuthTab] = useState<'login' | 'register'>('login');

  useEffect(() => {
    initUsers();
    const session = getSessionUser();
    if (session) {
      // Vérifier que l'utilisateur est toujours approuvé
      const users = getStoredUsers();
      const found = users.find((u) => u.id === session.id);
      if (found && found.status === 'approved') {
        setUser(session);
      } else {
        saveSession(null);
      }
    }
  }, []);

  function login(pseudo: string, password: string): { success: boolean; error?: string } {
    const users = getStoredUsers();
    const found = users.find(
      (u) =>
        (u.pseudo.toLowerCase() === pseudo.toLowerCase() ||
          u.email.toLowerCase() === pseudo.toLowerCase()) &&
        u.password === password
    );

    if (!found) {
      return { success: false, error: 'Pseudo/email ou mot de passe incorrect.' };
    }

    if (found.status === 'pending') {
      return {
        success: false,
        error: "⏳ Votre compte est en attente d'approbation par l'administrateur. Veuillez patienter.",
      };
    }

    if (found.status === 'rejected') {
      return {
        success: false,
        error: "❌ Votre demande d'inscription a été refusée. Contactez l'administrateur.",
      };
    }

    const { password: _, ...userData } = found;
    setUser(userData);
    saveSession(userData);
    setShowAuthModal(false);

    // Enregistrer la connexion dans le compteur
    addConnexionLog(found.pseudo);

    return { success: true };
  }

  function register(data: RegisterData): { success: boolean; error?: string } {
    const users = getStoredUsers();

    if (users.some((u) => u.pseudo.toLowerCase() === data.pseudo.toLowerCase())) {
      return { success: false, error: 'Ce pseudo est déjà pris.' };
    }

    if (users.some((u) => u.email.toLowerCase() === data.email.toLowerCase())) {
      return { success: false, error: 'Cet email est déjà utilisé.' };
    }

    if (data.pseudo.length < 3) {
      return { success: false, error: 'Le pseudo doit faire au moins 3 caractères.' };
    }
    if (data.password.length < 4) {
      return { success: false, error: 'Le mot de passe doit faire au moins 4 caractères.' };
    }
    if (!data.email.includes('@')) {
      return { success: false, error: 'Email invalide.' };
    }

    const newUser: StoredUser = {
      id: Date.now().toString(),
      pseudo: data.pseudo,
      email: data.email,
      nom: data.nom,
      prenom: data.prenom,
      password: data.password,
      role: 'membre',
      status: 'pending', // En attente d'approbation !
      dateInscription: new Date().toLocaleDateString('fr-FR'),
      avatar: getRandomAvatar(),
    };

    users.push(newUser);
    saveStoredUsers(users);

    return { success: true };
  }

  function logout() {
    setUser(null);
    saveSession(null);
  }

  function getAllUsers(): StoredUser[] {
    return getStoredUsers();
  }

  function approveUser(id: string) {
    const users = getStoredUsers();
    const idx = users.findIndex((u) => u.id === id);
    if (idx !== -1) {
      users[idx].status = 'approved';
      saveStoredUsers(users);
    }
  }

  function rejectUser(id: string) {
    const users = getStoredUsers();
    const idx = users.findIndex((u) => u.id === id);
    if (idx !== -1) {
      users[idx].status = 'rejected';
      saveStoredUsers(users);
    }
  }

  function deleteUser(id: string) {
    if (id === 'admin-001') return; // Ne pas supprimer l'admin
    const users = getStoredUsers().filter((u) => u.id !== id);
    saveStoredUsers(users);
  }

  function getPendingCount(): number {
    return getStoredUsers().filter((u) => u.status === 'pending').length;
  }

  function changePassword(currentPassword: string, newPassword: string): { success: boolean; error?: string } {
    if (!user) {
      return { success: false, error: 'Vous devez être connecté.' };
    }

    const users = getStoredUsers();
    const idx = users.findIndex((u) => u.id === user.id);

    if (idx === -1) {
      return { success: false, error: 'Utilisateur introuvable.' };
    }

    // Vérifier l'ancien mot de passe
    if (users[idx].password !== currentPassword) {
      return { success: false, error: 'Mot de passe actuel incorrect.' };
    }

    // Validation nouveau mot de passe
    if (newPassword.length < 4) {
      return { success: false, error: 'Le nouveau mot de passe doit faire au moins 4 caractères.' };
    }

    if (currentPassword === newPassword) {
      return { success: false, error: "Le nouveau mot de passe doit être différent de l'ancien." };
    }

    // Mettre à jour
    users[idx].password = newPassword;
    saveStoredUsers(users);

    return { success: true };
  }

  function addConnexionLog(pseudo: string) {
    try {
      const now = new Date();
      const log: ConnexionLog = {
        pseudo,
        date: now.toLocaleDateString('fr-FR'),
        heure: now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        annee: now.getFullYear().toString(),
      };
      const logs: ConnexionLog[] = JSON.parse(localStorage.getItem('pn_connexion_logs') || '[]');
      logs.unshift(log);
      // Garder max 1000 logs
      if (logs.length > 1000) logs.length = 1000;
      localStorage.setItem('pn_connexion_logs', JSON.stringify(logs));
    } catch { /* ignore */ }
  }

  function getConnexionStats(): { total: number; parAnnee: Record<string, number>; logs: ConnexionLog[] } {
    try {
      const logs: ConnexionLog[] = JSON.parse(localStorage.getItem('pn_connexion_logs') || '[]');
      const parAnnee: Record<string, number> = {};
      for (const log of logs) {
        parAnnee[log.annee] = (parAnnee[log.annee] || 0) + 1;
      }
      return { total: logs.length, parAnnee, logs };
    } catch {
      return { total: 0, parAnnee: {}, logs: [] };
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        showAuthModal,
        setShowAuthModal,
        authTab,
        setAuthTab,
        changePassword,
        getAllUsers,
        approveUser,
        rejectUser,
        deleteUser,
        getPendingCount,
        getConnexionStats,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
