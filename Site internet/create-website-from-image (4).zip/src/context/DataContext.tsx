import { createContext, useContext, useState } from 'react';
import type { ReactNode } from 'react';

// ===== TYPES =====
export interface NewsItem {
  id: string;
  date: string;
  title: string;
  description: string;
  tag: string;
}

export interface EventItem {
  id: string;
  date: string;
  title: string;
  location: string;
  participants: string;
}

export interface Dirigeant {
  id: string;
  role: string;
  name: string;
  phone: string;
  email: string;
  photo: string;
  ordre: number; // pour l'ordre dans l'organigramme (1=Président, 2=Vice, etc.)
}

export interface Arbitre {
  id: string;
  nom: string;
  prenom: string;
  phone: string;
  email: string;
  photo: string;
  niveau: 'Départemental' | 'Régional' | 'National' | 'Club';
  ordre: number;
}

export interface ClubInfo {
  adresse: string;
  email: string;
  telephone: string;
  horaires: string[];
}

export interface Joueur {
  id: string;
  nom: string;
  pts: number;
  v: number;
  d: number;
}

export interface JoueurClub {
  id: string;
  nom: string;
  prenom: string;
  dateNaissance: string;
  genre: 'masculin' | 'feminin';
  categorie: 'Elite' | 'Honneur' | 'Promotion' | 'Non classé';
  photo: string; // base64 data URL ou vide
}

// ===== COMPETITIONS / CLASSEMENTS =====
export interface ClubClassement {
  id: string;
  nom: string;
  isHome: boolean; // true = Pétanque Naintréenne
  j: number;  // joués
  v: number;  // victoires
  n: number;  // nuls
  d: number;  // défaites
  forf: number; // forfaits
  bp: number; // boules pour
  bc: number; // boules contre
}

export interface Competition {
  id: string;
  nom: string;
  clubs: ClubClassement[];
  bareme: { victoire: number; nul: number; defaite: number; forfait: number };
}

export interface Equipe {
  id: string;
  name: string;
  division: string;
  joueurs: string[];
  resultats: string;
}

export interface MatchItem {
  id: string;
  date: string;
  match: string;
  lieu: string;
  resultat: string;
}

export interface MediaItem {
  id: string;
  title: string;
  type: 'photo' | 'video';
  count: number;
}

export interface PartenaireItem {
  id: string;
  name: string;
  type: string;
  description: string;
}

export interface ForumTopic {
  id: string;
  title: string;
  author: string;
  date: string;
  replies: number;
  likes: number;
  category: string;
}

export interface FAQItem {
  id: string;
  q: string;
  a: string;
}

export interface LicenceItem {
  id: string;
  title: string;
  subtitle: string;
  price: string;
  popular?: boolean;
}

export interface InscriptionLicence {
  id: string;
  licenceTitle: string;
  nom: string;
  prenom: string;
  dateNaissance: string;
  adresse: string;
  email: string;
  telephone: string;
  dateInscription: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface SaisonInfo {
  annee: string;
}

export interface ClubMeta {
  dateFondation: string;
}

// ===== DONNÉES PAR DÉFAUT =====
const defaultNews: NewsItem[] = [
  { id: '1', date: '15 Janvier 2025', title: 'Concours de Doublettes – Résultats', description: 'Belle journée de pétanque avec 32 équipes engagées. Félicitations aux vainqueurs Jean-Pierre et Michel !', tag: 'Résultats' },
  { id: '2', date: '10 Janvier 2025', title: 'Tournoi Interclubs Vienne', description: 'Notre équipe a brillamment représenté le club lors du tournoi interclubs départemental. 3ème place au général !', tag: 'Compétition' },
  { id: '3', date: '5 Janvier 2025', title: 'Galette des Rois au Club', description: 'Merci à tous les membres présents pour ce moment convivial.', tag: 'Vie du club' },
];

const defaultEvents: EventItem[] = [
  { id: '1', date: '25 Jan', title: 'Concours Triplettes', location: 'Boulodrome de Naintré', participants: '48 équipes max' },
  { id: '2', date: '8 Fév', title: 'Tournoi Nocturne', location: 'Boulodrome couvert', participants: '24 équipes max' },
];

const defaultDirigeants: Dirigeant[] = [
  { id: '1', role: 'Président', name: 'Jean-Pierre Martin', phone: '06 12 34 56 78', email: '', photo: '', ordre: 1 },
  { id: '2', role: 'Vice-Président', name: 'Michel Dupont', phone: '06 23 45 67 89', email: '', photo: '', ordre: 2 },
  { id: '3', role: 'Secrétaire', name: 'Marie Lefèvre', phone: '06 34 56 78 90', email: '', photo: '', ordre: 3 },
  { id: '4', role: 'Trésorier', name: 'Pierre Moreau', phone: '06 45 67 89 01', email: '', photo: '', ordre: 4 },
];

const defaultArbitres: Arbitre[] = [];

const defaultClubInfo: ClubInfo = {
  adresse: 'Boulodrome Municipal\nRue du Stade\n86530 Naintré',
  email: 'petanque.naintreenne@email.fr',
  telephone: '05 49 XX XX XX',
  horaires: ['Mercredi : 14h – 18h', 'Samedi : 14h – 18h', 'Dimanche : 9h – 12h'],
};

const defaultJoueurs: Joueur[] = [
  { id: '1', nom: 'J-P. Martin', pts: 245, v: 18, d: 4 },
  { id: '2', nom: 'M. Dupont', pts: 230, v: 17, d: 5 },
  { id: '3', nom: 'P. Moreau', pts: 215, v: 15, d: 7 },
  { id: '4', nom: 'L. Bernard', pts: 198, v: 14, d: 8 },
  { id: '5', nom: 'A. Petit', pts: 185, v: 13, d: 9 },
];

const defaultCompetitions: Competition[] = [
  {
    id: 'comp1', nom: 'Division 1 – CDC Masculin',
    bareme: { victoire: 3, nul: 2, defaite: 1, forfait: 0 },
    clubs: [
      { id: 'c1', nom: 'Pétanque Naintréenne', isHome: true, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c2', nom: 'Club de Châtellerault', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c3', nom: 'Club de Poitiers', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c4', nom: 'Club de Loudun', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c5', nom: 'Club de Montmorillon', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c6', nom: 'Club de Civray', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
    ],
  },
  {
    id: 'comp2', nom: 'Division 2 – CDC Féminin',
    bareme: { victoire: 3, nul: 2, defaite: 1, forfait: 0 },
    clubs: [
      { id: 'c7', nom: 'Pétanque Naintréenne', isHome: true, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c8', nom: 'Club de Châtellerault', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c9', nom: 'Club de Poitiers', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c10', nom: 'Club de Loudun', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
    ],
  },
  {
    id: 'comp3', nom: 'Division 3 – Vétérans',
    bareme: { victoire: 3, nul: 2, defaite: 1, forfait: 0 },
    clubs: [
      { id: 'c11', nom: 'Pétanque Naintréenne', isHome: true, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c12', nom: 'Club de Châtellerault', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c13', nom: 'Club de Poitiers', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c14', nom: 'Club de Vivonne', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
      { id: 'c15', nom: 'Club de Chauvigny', isHome: false, j: 0, v: 0, n: 0, d: 0, forf: 0, bp: 0, bc: 0 },
    ],
  },
];

const defaultEquipes: Equipe[] = [];

const defaultJoueursClub: JoueurClub[] = [];

const defaultMatchs: MatchItem[] = [
  { id: '1', date: '12 Jan', match: 'Naintré vs Châtellerault', lieu: 'Domicile', resultat: '3-1' },
  { id: '2', date: '19 Jan', match: 'Poitiers vs Naintré', lieu: 'Extérieur', resultat: '2-2' },
  { id: '3', date: '26 Jan', match: 'Naintré vs Loudun', lieu: 'Domicile', resultat: 'À venir' },
];

const defaultMedias: MediaItem[] = [
  { id: '1', title: 'Concours Doublettes Janvier 2025', type: 'photo', count: 24 },
  { id: '2', title: 'Tournoi Interclubs Vienne', type: 'photo', count: 36 },
  { id: '3', title: 'Galette des Rois 2025', type: 'photo', count: 18 },
  { id: '4', title: 'Finale Départementale 2024', type: 'video', count: 3 },
];

const defaultPartenaires: PartenaireItem[] = [
  { id: '1', name: 'Mairie de Naintré', type: 'Partenaire institutionnel', description: 'Soutien municipal et mise à disposition du boulodrome.' },
  { id: '2', name: 'Crédit Agricole', type: 'Sponsor principal', description: 'Partenaire financier depuis 2018.' },
  { id: '3', name: 'Boulangerie Durand', type: 'Sponsor', description: 'Fournisseur officiel des concours du club.' },
];

const defaultForum: ForumTopic[] = [
  { id: '1', title: 'Organisation du prochain concours triplettes', author: 'Jean-Pierre M.', date: 'Il y a 2h', replies: 12, likes: 5, category: 'Organisation' },
  { id: '2', title: 'Retour sur le tournoi de Châtellerault', author: 'Michel D.', date: 'Il y a 5h', replies: 8, likes: 3, category: 'Compétition' },
  { id: '3', title: 'Conseil achat de boules pour débutant', author: 'Sophie T.', date: 'Hier', replies: 15, likes: 7, category: 'Matériel' },
];

const defaultFAQ: FAQItem[] = [
  { id: '1', q: "Comment s'inscrire au club ?", a: "Rendez-vous au boulodrome aux horaires d'ouverture avec un certificat médical, une photo d'identité et le montant de la cotisation." },
  { id: '2', q: "Quels sont les horaires d'entraînement ?", a: 'Les entraînements ont lieu le mercredi de 14h à 18h et le samedi de 14h à 18h.' },
  { id: '3', q: 'Faut-il avoir ses propres boules ?', a: 'Non, le club peut vous prêter des boules pour commencer.' },
  { id: '4', q: 'À partir de quel âge peut-on jouer ?', a: 'Dès 6 ans ! La licence est gratuite pour les jeunes de moins de 11 ans.' },
];

const defaultLicences: LicenceItem[] = [
  { id: '1', title: 'Jeunes', subtitle: 'Moins de 11 ans', price: 'Gratuit' },
  { id: '2', title: 'Juniors', subtitle: '11 à 17 ans', price: '15€' },
  { id: '3', title: 'Adultes', subtitle: '18 ans et plus', price: '40€', popular: true },
  { id: '4', title: 'Loisir', subtitle: 'Sans compétition', price: '20€' },
];

const defaultInscriptions: InscriptionLicence[] = [];

const defaultSaisonInfo: SaisonInfo = { annee: '2024–2025' };

const defaultClubMeta: ClubMeta = { dateFondation: '' };

// ===== CONTEXT =====
interface DataContextType {
  news: NewsItem[]; setNews: (d: NewsItem[]) => void;
  events: EventItem[]; setEvents: (d: EventItem[]) => void;
  dirigeants: Dirigeant[]; setDirigeants: (d: Dirigeant[]) => void;
  arbitres: Arbitre[]; setArbitres: (d: Arbitre[]) => void;
  clubInfo: ClubInfo; setClubInfo: (d: ClubInfo) => void;
  joueurs: Joueur[]; setJoueurs: (d: Joueur[]) => void;
  equipes: Equipe[]; setEquipes: (d: Equipe[]) => void;
  competitions: Competition[]; setCompetitions: (d: Competition[]) => void;
  joueursClub: JoueurClub[]; setJoueursClub: (d: JoueurClub[]) => void;
  matchs: MatchItem[]; setMatchs: (d: MatchItem[]) => void;
  medias: MediaItem[]; setMedias: (d: MediaItem[]) => void;
  partenaires: PartenaireItem[]; setPartenaires: (d: PartenaireItem[]) => void;
  forum: ForumTopic[]; setForum: (d: ForumTopic[]) => void;
  faq: FAQItem[]; setFAQ: (d: FAQItem[]) => void;
  licences: LicenceItem[]; setLicences: (d: LicenceItem[]) => void;
  inscriptions: InscriptionLicence[]; setInscriptions: (d: InscriptionLicence[]) => void;
  getPendingInscriptions: () => number;
  saisonInfo: SaisonInfo; setSaisonInfo: (d: SaisonInfo) => void;
  clubMeta: ClubMeta; setClubMeta: (d: ClubMeta) => void;
}

const DataContext = createContext<DataContextType | null>(null);

const DATA_VERSION = 'v4';

function initDataVersion() {
  const stored = localStorage.getItem('pn_data_version');
  if (stored !== DATA_VERSION) {
    localStorage.removeItem('pn_data_equipes');
    localStorage.removeItem('pn_data_dirigeants');
    localStorage.removeItem('pn_data_licences');
    localStorage.setItem('pn_data_version', DATA_VERSION);
  }
}
initDataVersion();

function load<T>(key: string, fallback: T): T {
  try {
    const d = localStorage.getItem('pn_data_' + key);
    return d ? JSON.parse(d) : fallback;
  } catch { return fallback; }
}

function save<T>(key: string, data: T) {
  localStorage.setItem('pn_data_' + key, JSON.stringify(data));
}

export function DataProvider({ children }: { children: ReactNode }) {
  const [news, _setNews] = useState<NewsItem[]>(() => load('news', defaultNews));
  const [events, _setEvents] = useState<EventItem[]>(() => load('events', defaultEvents));
  const [dirigeants, _setDirigeants] = useState<Dirigeant[]>(() => load('dirigeants', defaultDirigeants));
  const [arbitres, _setArbitres] = useState<Arbitre[]>(() => load('arbitres', defaultArbitres));
  const [clubInfo, _setClubInfo] = useState<ClubInfo>(() => load('clubInfo', defaultClubInfo));
  const [joueurs, _setJoueurs] = useState<Joueur[]>(() => load('joueurs', defaultJoueurs));
  const [equipes, _setEquipes] = useState<Equipe[]>(() => load('equipes', defaultEquipes));
  const [competitions, _setCompetitions] = useState<Competition[]>(() => load('competitions', defaultCompetitions));
  const [joueursClub, _setJoueursClub] = useState<JoueurClub[]>(() => load('joueursClub', defaultJoueursClub));
  const [matchs, _setMatchs] = useState<MatchItem[]>(() => load('matchs', defaultMatchs));
  const [medias, _setMedias] = useState<MediaItem[]>(() => load('medias', defaultMedias));
  const [partenaires, _setPartenaires] = useState<PartenaireItem[]>(() => load('partenaires', defaultPartenaires));
  const [forum, _setForum] = useState<ForumTopic[]>(() => load('forum', defaultForum));
  const [faq, _setFAQ] = useState<FAQItem[]>(() => load('faq', defaultFAQ));
  const [licences, _setLicences] = useState<LicenceItem[]>(() => load('licences', defaultLicences));
  const [inscriptions, _setInscriptions] = useState<InscriptionLicence[]>(() => load('inscriptions', defaultInscriptions));
  const [saisonInfo, _setSaisonInfo] = useState<SaisonInfo>(() => load('saisonInfo', defaultSaisonInfo));
  const [clubMeta, _setClubMeta] = useState<ClubMeta>(() => load('clubMeta', defaultClubMeta));

  function setNews(d: NewsItem[]) { _setNews(d); save('news', d); }
  function setEvents(d: EventItem[]) { _setEvents(d); save('events', d); }
  function setDirigeants(d: Dirigeant[]) { _setDirigeants(d); save('dirigeants', d); }
  function setArbitres(d: Arbitre[]) { _setArbitres(d); save('arbitres', d); }
  function setClubInfo(d: ClubInfo) { _setClubInfo(d); save('clubInfo', d); }
  function setJoueurs(d: Joueur[]) { _setJoueurs(d); save('joueurs', d); }
  function setEquipes(d: Equipe[]) { _setEquipes(d); save('equipes', d); }
  function setCompetitions(d: Competition[]) { _setCompetitions(d); save('competitions', d); }
  function setJoueursClub(d: JoueurClub[]) { _setJoueursClub(d); save('joueursClub', d); }
  function setMatchs(d: MatchItem[]) { _setMatchs(d); save('matchs', d); }
  function setMedias(d: MediaItem[]) { _setMedias(d); save('medias', d); }
  function setPartenaires(d: PartenaireItem[]) { _setPartenaires(d); save('partenaires', d); }
  function setForum(d: ForumTopic[]) { _setForum(d); save('forum', d); }
  function setFAQ(d: FAQItem[]) { _setFAQ(d); save('faq', d); }
  function setLicences(d: LicenceItem[]) { _setLicences(d); save('licences', d); }
  function setInscriptions(d: InscriptionLicence[]) { _setInscriptions(d); save('inscriptions', d); }
  function getPendingInscriptions(): number { return inscriptions.filter(i => i.status === 'pending').length; }
  function setSaisonInfo(d: SaisonInfo) { _setSaisonInfo(d); save('saisonInfo', d); }
  function setClubMeta(d: ClubMeta) { _setClubMeta(d); save('clubMeta', d); }

  return (
    <DataContext.Provider value={{
      news, setNews, events, setEvents, dirigeants, setDirigeants, arbitres, setArbitres,
      clubInfo, setClubInfo, joueurs, setJoueurs, equipes, setEquipes, competitions, setCompetitions, joueursClub, setJoueursClub,
      matchs, setMatchs, medias, setMedias, partenaires, setPartenaires,
      forum, setForum, faq, setFAQ, licences, setLicences, inscriptions, setInscriptions, getPendingInscriptions,
      saisonInfo, setSaisonInfo, clubMeta, setClubMeta,
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within DataProvider');
  return ctx;
}
