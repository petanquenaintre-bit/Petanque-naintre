import { AuthProvider } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import Navbar from './components/Navbar';
import AuthModal from './components/AuthModal';
import HeroBanner from './components/HeroBanner';
import CategoryCards from './components/CategoryCards';
import Actualites from './components/Actualites';
import Club from './components/Club';
import Saison from './components/Saison';
import Scores from './components/Scores';
import Medias from './components/Medias';
import Partenaires from './components/Partenaires';
import Licences from './components/Licences';
import FAQ from './components/FAQ';
import Forum from './components/Forum';
import Profil from './components/Profil';
import AdminPanel from './components/AdminPanel';
import Footer from './components/Footer';
import VisitorBar from './components/VisitorCounter';

export default function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <div className="min-h-screen bg-[#ecf0f1] font-sans pb-10">
          <Navbar />
          <AuthModal />
          <HeroBanner />
          <CategoryCards />
          <AdminPanel />
          <Profil />
          <Actualites />
          <Club />
          <Saison />
          <Scores />
          <Medias />
          <Partenaires />
          <Licences />
          <FAQ />
          <Forum />
          <Footer />
          <VisitorBar />
        </div>
      </DataProvider>
    </AuthProvider>
  );
}
